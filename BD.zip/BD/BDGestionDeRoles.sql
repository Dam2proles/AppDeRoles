 DROP TABLE ARMAMENTO;
 DROP TABLE CAPACIDAD;
 DROP TABLE ARMA;
 DROP TABLE CICATRIZ;
 DROP TABLE FAMILIA;
 DROP TABLE HABILIDAD;
 DROP TABLE HECHIZO;
 DROP TABLE HERIDA;
 DROP TABLE LIBRO;
 DROP TABLE OBJETO;
 DROP TABLE POSESION;
 DROP TABLE PROPIEDAD;
 DROP TABLE SER;
 DROP TABLE TITULO;
 DROP TABLE TRASTORNO;
 DROP TABLE PERSONAJE;
 DROP TABLE USUARIO;
 DROP TABLE CAMPA�A;
 

 
 
 
 CREATE TABLE USUARIO(
    nombre_usu VARCHAR2(100),
    contrase�a VARCHAR2(100) NOT NULL,
    email VARCHAR2(100) NOT NULL,
    sexo VARCHAR2(1) NOT NULL,
    fec_nacimiento DATE,
    tipo_perfil VARCHAR2(10) NOT NULL,
    CONSTRAINT pk_usuario PRIMARY KEY (nombre_usu),
    CONSTRAINT ck_sexo CHECK(sexo='H' OR sexo='M'),
    CONSTRAINT ck_perfil CHECK(tipo_perfil='p�blico' OR tipo_perfil='privado')
    
    );
    
    
    
CREATE TABLE CAMPA�A(
  nombre_camp VARCHAR2(100),
  creador VARCHAR2(100) NOT NULL,
  descripcion VARCHAR2(1000),
  CONSTRAINT pk_campa�a PRIMARY KEY(nombre_camp)
    
);





CREATE TABLE PERSONAJE(
    id_personaje NUMBER ,
    nombre_usuario VARCHAR2(100) NOT NULL,
    nombre_personaje VARCHAR2(100) NOT NULL,
    nombre_campa�a VARCHAR2(100) NOT NULL,
    profesion VARCHAR2(100) NOT NULL,
    edad NUMBER NOT NULL,
    lugar_nac VARCHAR2(100) NOT NULL,
    fuerza NUMBER NOT NULL,
    constitucion NUMBER NOT NULL,
    tama�o NUMBER NOT NULL,
    destreza NUMBER NOT NULL,
    apariencia NUMBER NOT NULL,
    cordura NUMBER NOT NULL,
    inteligencia NUMBER NOT NULL,
    poder NUMBER NOT NULL,
    educacion NUMBER NOT NULL,
    idea NUMBER NOT NULL,
    suerte NUMBER NOT NULL,
    conocimiento NUMBER NOT NULL,
    CONSTRAINT pk_personaje PRIMARY KEY (id_personaje),
    CONSTRAINT fk_personaje_usuario FOREIGN KEY (nombre_usuario) REFERENCES USUARIO(nombre_usu) ON DELETE CASCADE,
    CONSTRAINT fk_personaje_campa�a FOREIGN KEY (nombre_campa�a) REFERENCES CAMPA�A(nombre_camp) ON DELETE CASCADE 
    
    );
    
    

    
CREATE TABLE TITULO(
    nombre_titulo VARCHAR2(100) ,
    id_pers INT,
    CONSTRAINT pk_titulo PRIMARY KEY (nombre_titulo,id_pers),
    CONSTRAINT fk_titulo_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);

CREATE TABLE FAMILIA(
    familiar VARCHAR2(100),
    id_pers INT,
    CONSTRAINT pk_familia PRIMARY KEY(familiar,id_pers),
    CONSTRAINT fk_familia_personaje FOREIGN KEY(id_pers) REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);


CREATE TABLE TRASTORNO(
    nombre_trastorno VARCHAR2(100),
    id_pers INT,
    CONSTRAINT pk_trastorno PRIMARY KEY(nombre_trastorno,id_pers),
    CONSTRAINT fk_trastorno_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);

CREATE TABLE HABILIDAD(
    nombre_habilidad VARCHAR2(50),
    CONSTRAINT pk_habilidad PRIMARY KEY(nombre_habilidad)
    
);


CREATE TABLE ARMA(
    nombre_arma VARCHAR2(50),
    CONSTRAINT pk_arma PRIMARY KEY(nombre_arma)
);

CREATE TABLE HERIDA(
    nombre_herida VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_herida PRIMARY KEY(nombre_herida,id_pers),
    CONSTRAINT fk_herida_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);
    
CREATE TABLE CICATRIZ(
    nombre_cicatriz VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_cicatriz PRIMARY KEY(nombre_cicatriz,id_pers),
    CONSTRAINT fk_cicatriz_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);


CREATE TABLE PROPIEDAD(
    nombre_propiedad VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_propiedad PRIMARY KEY(nombre_propiedad,id_pers),
    CONSTRAINT fk_propiedad_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);
    
    
CREATE TABLE POSESION (
    nombre_posesion VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_posesion PRIMARY KEY(nombre_posesion,id_pers),
    CONSTRAINT fk_posesion_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
    
);


CREATE TABLE LIBRO(
    nombre_libro VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_libro PRIMARY KEY(nombre_libro,id_pers),
    CONSTRAINT fk_libro_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE

);

CREATE TABLE OBJETO(
    nombre_objeto VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_objeto PRIMARY KEY(nombre_objeto,id_pers),
    CONSTRAINT fk_objeto_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);

CREATE TABLE HECHIZO(
    nombre_hechizo VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_hechizo PRIMARY KEY(nombre_hechizo,id_pers),
    CONSTRAINT fk_hechizo_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
    
);

CREATE TABLE SER(
    nombre_ser VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_ser PRIMARY KEY(nombre_ser,id_pers),
    CONSTRAINT fk_ser_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
    
);


CREATE TABLE CAPACIDAD(
    nombre_habi VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_capacidad PRIMARY KEY(nombre_habi,id_pers),
    CONSTRAINT fk_capacidad_habilidad FOREIGN KEY(nombre_habi) REFERENCES HABILIDAD(nombre_habilidad) ON DELETE CASCADE,
    CONSTRAINT fk_capacidad_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
    

);


CREATE TABLE ARMAMENTO(
    nom_arma VARCHAR2(50),
    id_pers INT,
    CONSTRAINT pk_armamento PRIMARY KEY(nom_arma,id_pers),
    CONSTRAINT fk_armamento_arma FOREIGN KEY(nom_arma) REFERENCES ARMA(nombre_arma) ON DELETE CASCADE,
    CONSTRAINT fk_armamento_personaje FOREIGN KEY(id_pers)REFERENCES PERSONAJE(id_personaje)ON DELETE CASCADE
);


CREATE SEQUENCE S_PERSONAJE
START WITH 1
INCREMENT BY 1;

CREATE OR REPLACE TRIGGER T_PERSONAJE
BEFORE INSERT ON PERSONAJE
FOR EACH ROW
BEGIN
SELECT S_PERSONAJE.NEXTVAL 
INTO :NEW.id_personaje  
FROM DUAL;
END;



/

INSERT INTO USUARIO VALUES('Sergio','12345','correo1@gmail.com','H','20-03-2000','p�blico');
INSERT INTO USUARIO VALUES('Rub�n','23456','correo2@gmail.com','H','2-06-1998','privado');
INSERT INTO USUARIO VALUES('Fran','34567','correo3@gmail.com','H','10-10-2000','p�blico');



INSERT INTO CAMPA�A VALUES('Las m�scaras de Nyarlathotep','Edge Entertainment','Por fin las estrellas casi est�n en la posici�n correcta.
                            Pronto los planes de Nyarlathotep dar�n fruto, y el mundo cambiar� de forma irrevocable... pero a�n no. 
                            Un grupo de molestos investigadores humanos ha averiguado demasiadas cosas. Ahora deben sobrevivir lo suficiente como para encontrar sentido a lo que saben
                            y actuar de forma resuelta.');
INSERT INTO CAMPA�A VALUES('Horror en el Orient Express','Chaosium Inc.','"Horror en el Orient Express" es una campa�a larga y emblem�tica, en la que los investigadores recorrer�n Europa
                            a bordo del Orient Express (concretamente desde Par�s a Constantinopla, aunque la partida empieza y acaba en Londres) con el objetivo de reunir las diferentes piezas
                            de un rar�simo objeto de los Mitos. La propia concepci�n o idea de la campa�a hace que esta sea excesivamente lineal');
                            
                  
INSERT INTO PERSONAJE(nombre_usuario,nombre_personaje,nombre_campa�a,profesion,edad,lugar_nac,fuerza,constitucion,tama�o,destreza,apariencia,cordura,inteligencia,poder,educacion,idea,suerte,conocimiento) VALUES('Sergio','Roberto Garc�a','Las m�scaras de Nyarlathotep','profesor','35','Espa�a',56,70,85,55,50,80,40,70,45,200,225,350);
INSERT INTO PERSONAJE(nombre_usuario,nombre_personaje,nombre_campa�a,profesion,edad,lugar_nac,fuerza,constitucion,tama�o,destreza,apariencia,cordura,inteligencia,poder,educacion,idea,suerte,conocimiento) VALUES('Rub�n','Iv�n Gonz�lez','Horror en el Orient Express','comerciante','29','Alemania',62,70,63,35,90,74,64,82,56,320,255,410);
INSERT INTO PERSONAJE(nombre_usuario,nombre_personaje,nombre_campa�a,profesion,edad,lugar_nac,fuerza,constitucion,tama�o,destreza,apariencia,cordura,inteligencia,poder,educacion,idea,suerte,conocimiento) VALUES('Fran','Manuel Trujillo','Las m�scaras de Nyarlathotep','herrero','46','Francia',58,60,71,41,49,60,30,80,52,150,260,400);
                  
                  
                
                            
INSERT INTO ARMA VALUES('Cabezazo');
INSERT INTO ARMA VALUES('Patada');
INSERT INTO ARMA VALUES('Cuchillo');
INSERT INTO ARMA VALUES('Pistola');


INSERT INTO CICATRIZ VALUES('X en el ojo izquierdo',1);
INSERT INTO CICATRIZ VALUES('Cicatriz en la nariz',2);

INSERT INTO FAMILIA VALUES('Ana Garc�a',1);
INSERT INTO FAMILIA VALUES('Pedro Gonz�lez',2);

INSERT INTO HABILIDAD VALUES('Arqueolog�a');
INSERT INTO HABILIDAD VALUES('Electricidad');
INSERT INTO HABILIDAD VALUES('Primeros Auxilios');

INSERT INTO CAPACIDAD VALUES('Primeros Auxilios',1);
INSERT INTO CAPACIDAD VALUES('Electricidad',2);
INSERT INTO CAPACIDAD VALUES('Arqueolog�a',3);

INSERT INTO ARMAMENTO VALUES('Cabezazo',1);
INSERT INTO ARMAMENTO VALUES('Cuchillo',1);
INSERT INTO ARMAMENTO VALUES('Patada',2);
INSERT INTO ARMAMENTO VALUES('Pistola',3);







