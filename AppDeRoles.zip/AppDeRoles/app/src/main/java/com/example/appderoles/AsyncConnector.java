package com.example.appderoles;

import java.util.ArrayList;

import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;



public class AsyncConnector extends AsyncTask <void, void, void> {
    private ArrayList<String> data;
    private ArrayAdapter<String> adapter;
    private String url;
    private ProgressDialog pd;
    private Context context;

    public AsyncConnector(Context context, ArrayAdapter<String> adapter, String url){
        this.adapter = adapter;
        this.url = url;
        pd= new ProgressDialog(context);
        this.context = context;
    }
    @Override
    protected void onPreExecute() {
        pd.setIndeterminate(true);
        pd.setMessage(context.getResources().getString(R.string.MessageProgressDialog));
        pd.setTitle(R.string.TitleProgressDialog);
        pd.show();
        super.onPreExecute();
    }

    protected void doInBackground(Void... Params){
        ConectorHttpJSON conector = new ConectorHttpJSON(url);

        try {

            JSONObject obj = conector.execute();


            data = new JSONToStringCollection(obj).getArrayList();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void result) {

        for (String tmp : data)
            adapter.add(tmp);


        adapter.notifyDataSetChanged();


        pd.dismiss();
        super.onPostExecute(result);
    }
}
