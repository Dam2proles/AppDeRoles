package com.example.appderoles;

import android.app.Application;
import android.content.Context;
import android.widget.ArrayAdapter;

import com.example.appderoles.AsyncConnector;

public class JSONApplication {
    private final static String URL="";

    public void getData(Context context,ArrayAdapter<String> adapter){
        new AsyncConnector(context, adapter, URL).execute();
    }
}
