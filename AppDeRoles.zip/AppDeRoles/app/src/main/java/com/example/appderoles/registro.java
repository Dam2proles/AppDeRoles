package com.example.appderoles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class registro extends AppCompatActivity {
    EditText txtNick;
    EditText txtEmail;
    EditText password;
    EditText conPassword;
    String email;
    String nickname;
    String password1;
    String password2;
    Boolean confirmado = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        txtNick = (EditText)findViewById(R.id.txtNickname);
        txtEmail = (EditText)findViewById(R.id.txtEmail);
        password = (EditText)findViewById(R.id.txtCont);
        conPassword = (EditText)findViewById(R.id.txtConfCont);
    }
    public void recogerdatos(){
        email = txtEmail.getText().toString();
        nickname = txtNick.getText().toString();
        password1 =  password.getText().toString();
        password2 = conPassword.getText().toString();
    }
    public void validarCont(){
        Context contexto = getApplicationContext();
        Toast toast;
        int duracion = Toast.LENGTH_LONG;
        password1 =  password.getText().toString();
        password2 = conPassword.getText().toString();
        if (password1.equals(password2)) {
            confirmado = true;

        }else {
            confirmado = false;
        }
        if(confirmado == false){
            toast=Toast.makeText(contexto,"Por favor, compruebe que las contraseñas coinciden.",duracion);
            toast.show();
        }
    }
}
