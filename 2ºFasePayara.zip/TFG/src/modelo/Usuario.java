package modelo;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class Usuario {
	String nombre_usu;
	String contrasenia;
	String email;
	String sexo;
	Date fec_nacimiento;
	String tipo_perfil;

	public Usuario(String nombre_usu, String contrasenia, String email, String sexo, Date fec_nacimiento,
			String tipo_perfil) {
		this.nombre_usu = nombre_usu;
		this.contrasenia = contrasenia;
		this.email = email;
		this.sexo = sexo;
		this.fec_nacimiento = fec_nacimiento;
		this.tipo_perfil = tipo_perfil;
	}

	public Usuario() {
		// TODO Auto-generated constructor stub
	}

	public String getNombre_usu() {
		return nombre_usu;
	}

	public void setNombre_usu(String nombre_usu) {
		this.nombre_usu = nombre_usu;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Date getFec_nacimiento() {
		return fec_nacimiento;
	}

	public void setFec_nacimiento(Date fec_nacimiento) {
		this.fec_nacimiento = fec_nacimiento;
	}

	public String getTipo_perfil() {
		return tipo_perfil;
	}

	public void setTipo_perfil(String tipo_perfil) {
		this.tipo_perfil = tipo_perfil;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	@Override
	public String toString() {
		return "Usuario [nombre_usu=" + nombre_usu + ", contrasenia=" + contrasenia + ", email=" + email + ", sexo="
				+ sexo + ", fec_nacimiento=" + fec_nacimiento + ", tipo_perfil=" + tipo_perfil + "]";
	}

}