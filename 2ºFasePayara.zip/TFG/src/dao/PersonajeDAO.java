package dao;

import modelo.Personaje;

public interface PersonajeDAO extends DAO<Personaje, Integer> {

}
