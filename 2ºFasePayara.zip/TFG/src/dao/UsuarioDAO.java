package dao;

import modelo.Usuario;

public interface UsuarioDAO extends DAO <Usuario, String> {

}
