package dao;

public interface DAOManager {

	UsuarioDAO getUsuarioDAO();
	
	PersonajeDAO getPersonajeDAO();
	
	CampaniaDAO getCampaniaDAO();
	
}
