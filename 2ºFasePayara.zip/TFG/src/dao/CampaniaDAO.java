package dao;

import modelo.Campania;

public interface CampaniaDAO extends DAO<Campania, Integer> {

}
