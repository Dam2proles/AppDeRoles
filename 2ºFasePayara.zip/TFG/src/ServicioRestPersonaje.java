import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import Exceptions.DAOException;
import daoMySQL.DAOManagerMySQL;
import modelo.Campania;
import modelo.Personaje;

public class ServicioRestPersonaje {

	// todas las personajes
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPersonajes() {

		Response.Status responseStatus = Response.Status.OK;
		List<Personaje> personajeRg = new LinkedList<Personaje>();

		try {
			DAOManagerMySQL man = new DAOManagerMySQL("localhost", "ejemplo", "ejemplo", "ejemplo");
			personajeRg = man.getPersonajeDAO().obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(personajeRg).build();
		else
			return Response.status(responseStatus).build();
	}

/*
 * 	// unico personaje
 
	@GET
	@Path("/{id_personaje}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getPersonaje(@PathParam("id_personaje") int idPersonaje) {

		Response.Status responseStatus = Response.Status.OK;
		Personaje personaje = null;
		try {
			DAOManagerMySQL man = new DAOManagerMySQL("localhost", "ejemplo", "ejemplo", "ejemplo");
			personaje = man.getPersonajeDAO().obtener(idPersonaje);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(personaje).build();
		else
			return Response.status(responseStatus).build();
	}*/

	// actualizar personaje
	@PUT
	@Path("/{id_campania}")
	@Consumes(APPLICATION_JSON)
	public Response putPersonaje(@PathParam("id_personaje") int idCampania, Campania camapnia) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			DAOManagerMySQL man = new DAOManagerMySQL("localhost", "ejemplo", "ejemplo", "ejemplo");
			man.getCampaniaDAO().modificar(camapnia);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	// insertar personaje
	@POST
	@Consumes(APPLICATION_JSON)
	public Response postPersonaje(@Context UriInfo uriInfo, Personaje personaje) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			DAOManagerMySQL man = new DAOManagerMySQL("localhost", "ejemplo", "ejemplo", "ejemplo");
			man.getPersonajeDAO().insertar(personaje);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

	// borrar personaje
	@DELETE
	@Path("/{id_usuario}")
	public Response deletePersonaje(@PathParam("id_campania") Personaje personaje) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			DAOManagerMySQL man = new DAOManagerMySQL("localhost", "ejemplo", "ejemplo", "ejemplo");
			man.getPersonajeDAO().eliminar(personaje);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
}
