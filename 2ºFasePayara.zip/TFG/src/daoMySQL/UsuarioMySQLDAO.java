package daoMySQL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Exceptions.DAOException;
import dao.UsuarioDAO;
import modelo.Usuario;

class UsuarioMySQLDAO implements UsuarioDAO {

	final String insert = "INSERT INTO usuarios (nombre_usu, contrase�a, email, sexo, fec_nacimiento, tipo_perfil) VALUES(?, ?, ?, ?, ?, ?)";
	final String update = "UPDATE usuarios SET contrase�a = ?, email = ?, sexo = ?, fec_nacimiento = ?, tipo_perfil = ? where nombre_usu = ? ";
	final String delete = "DELETE FROM usuarios where nombre_usu = ?";
	final String obtenerTodos = "Select nombre_usu, contrase�a, email, sexo, fec_nacimiento, tipo_perfil from usuarios";
	final String obtenerUno = "Select nombre_usu, contrase�a, email, sexo, fec_nacimiento, tipo_perfil from usuarios where nombre_usu = ?";

	private Connection con;

	public UsuarioMySQLDAO(Connection con) {
		this.con = con;
	}

	@Override
	public void insertar(Usuario a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(insert);
			stat.setString(1, a.getNombre_usu());
			stat.setString(2, a.getContrasenia());
			stat.setString(3, a.getEmail());
			stat.setString(4, a.getSexo());
			stat.setDate(5, new Date(a.getFec_nacimiento().getTime()));
			stat.setString(6, a.getTipo_perfil());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado el usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void modificar(Usuario a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(update);
			stat.setString(1, a.getContrasenia());
			stat.setString(2, a.getEmail());
			stat.setString(3, a.getSexo());
			stat.setDate(4, new Date(a.getFec_nacimiento().getTime()));
			stat.setString(5, a.getTipo_perfil());
			stat.setString(6, a.getNombre_usu());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado los cambios del usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void eliminar(Usuario a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(delete);
			stat.setString(1, a.getNombre_usu());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya brorrado el usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	/*
	 * este metodo nos sirve para transformar lo que nos de el resulset en objetos
	 * usuarios
	 */
	private Usuario convertir(ResultSet rs) throws SQLException {
		String nombre = rs.getString("nombre_usu");
		String contrasenia = rs.getString("contrasenia");
		String email = rs.getString("email");
		String sexo = rs.getString("sexo");
		Date fec_nacimiento = rs.getDate("fec_nacimiento");
		String tipo_sexo = rs.getString("tipo_sexo");
		Usuario usuario = new Usuario(nombre, contrasenia, email, sexo, fec_nacimiento, tipo_sexo);
		return usuario;
	}

	@Override
	public List<Usuario> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Usuario> users = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerTodos);
			rs = stat.executeQuery();
			while (rs.next()) {
				users.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return users;
	}

	@Override
	public Usuario obtener(String id) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Usuario u = null;
		try {
			stat = con.prepareStatement(obtenerUno);
			stat.setString(1, id);
			rs = stat.executeQuery();
			if (rs.next()) {
				u = convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return u;
	}

}
