package daoMySQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import dao.CampaniaDAO;
import dao.DAOManager;
import dao.PersonajeDAO;
import dao.UsuarioDAO;

public class DAOManagerMySQL implements DAOManager {

	private Connection conn;

	private UsuarioDAO users = null;
	private PersonajeDAO personajes = null;
	private CampaniaDAO campanias = null;

	public DAOManagerMySQL(String host, String username, String password, String database) throws SQLException {
		conn = DriverManager.getConnection("jdbc:mysql://" + host + "/" + database, username, password);
	}

	@Override
	public UsuarioDAO getUsuarioDAO() {
		if (users == null) {
			users = new UsuarioMySQLDAO(conn);
		}
		return users;
	}

	@Override
	public PersonajeDAO getPersonajeDAO() {
		if (personajes == null) {
			personajes = new PersonajeMySQLDAO(conn);
		}
		return personajes;
	}

	@Override
	public CampaniaDAO getCampaniaDAO() {
		if (campanias == null) {
			campanias = new CampaniaMySQLDAO(conn);
		}
		return campanias;
	}
}
