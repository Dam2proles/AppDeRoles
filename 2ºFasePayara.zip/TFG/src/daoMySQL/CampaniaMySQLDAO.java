package daoMySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Exceptions.DAOException;
import dao.CampaniaDAO;
import modelo.Campania;

public class CampaniaMySQLDAO implements CampaniaDAO {

	final String insert = "INSERT INTO campanias (nombre_camp, descripcion, creador) VALUES(?, ?, ?)";
	final String update = "UPDATE campanias SET descripcion = ?, creador = ? where nombre_camp = ? ";
	final String delete = "DELETE FROM campanias where nombre_camp = ?";
	final String obtenerTodos = "Select nombre_camp, descripcion, creador from campanias";
	final String obtenerUno = "Select nombre_camp, descripcion, creador from campanias where nombre_camp = ?";

	private Connection con;

	public CampaniaMySQLDAO(Connection con) {
		this.con = con;
	}

	@Override
	public void insertar(Campania a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(insert);
			stat.setString(1, a.getNombre());
			stat.setString(2, a.getDescripcion());
			stat.setString(3, a.getCreador());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado el usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void modificar(Campania a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(update);
			stat.setString(1, a.getDescripcion());
			stat.setString(2, a.getCreador());
			stat.setString(3, a.getNombre());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado los cambios del usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void eliminar(Campania a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(delete);
			stat.setString(1, a.getNombre());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya brorrado el usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
	}

	private Campania convertir(ResultSet rs) throws SQLException {
		String nombre = rs.getString("nombre");
		String descripcion = rs.getString("descripcion");
		String creador = rs.getString("creador");
		Campania campania = new Campania(nombre, descripcion, creador);
		return campania;
	}

	@Override
	public List<Campania> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Campania> campanias = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerTodos);
			rs = stat.executeQuery();
			while (rs.next()) {
				campanias.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return campanias;
	}

	@Override
	public Campania obtener(Integer id) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Campania camp = null;
		try {
			stat = con.prepareStatement(obtenerUno);
			stat.setInt(1, id);
			rs = stat.executeQuery();
			if (rs.next()) {
				camp = convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return camp;
	}
}
