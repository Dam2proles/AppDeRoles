package daoMySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Exceptions.DAOException;
import dao.PersonajeDAO;
import modelo.Personaje;

public class PersonajeMySQLDAO implements PersonajeDAO {

	final String insert = "INSERT INTO PERSONAJE (nombre_usuario,nombre_personaje,nombre_campaña,profesion,edad,lugar_nac,fuerza,constitucion,tamaño,"
			+ "destreza,apariencia,cordura,inteligencia,poder,educacion,idea,suerte,conocimiento) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	final String update = "UPDATE PERSONAJE SET profesion = ?, edad = ? WHERE nombre_personaje = ? ";
	final String delete = "DELETE FROM PERSONAJE WHERE nombre_usuario = ?, nombre_personaje = ?,nombre_campaña = ? ";
	final String obtenerTodos = "SELECT nombre_usuario,nombre_personaje,nombre_campaña,profesion,edad,lugar_nac,fuerza,constitucion,tamaño,destreza,"
			+ "apariencia,cordura,inteligencia,poder,educacion,idea,suerte,conocimiento FROM PERSONAJE";
	final String obtenerUno = "SELECT nombre_usuario,nombre_personaje,nombre_campaña,profesion,edad,lugar_nac,fuerza,constitucion,tamaño,destreza,"
			+ "apariencia,cordura,inteligencia,poder,educacion,idea,suerte,conocimiento FROM PERSONAJE WHERE nombre_usuario = ?, nombre_personaje = ?,nombre_campaña = ?";

	private Connection con;

	public PersonajeMySQLDAO(Connection con) {
		this.con = con;
	}

	@Override
	public void insertar(Personaje a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(insert);
			stat.setString(1, a.getUsuario());
			stat.setString(2, a.getNombre());
			stat.setString(3, a.getCampania());
			stat.setString(4, a.getProfesion());
			stat.setInt(5, a.getEdad());
			stat.setString(6, a.getLugarNacimiento());
			stat.setInt(7, a.getFuerza());
			stat.setInt(8, a.getConstitucion());
			stat.setInt(9, a.getTamanio());
			stat.setInt(10, a.getDestreza());
			stat.setInt(11, a.getApariencia());
			stat.setInt(12, a.getCordura());
			stat.setInt(13, a.getInteligencia());
			stat.setInt(14, a.getPoder());
			stat.setInt(15, a.getEducacion());
			stat.setInt(16, a.getIdea());
			stat.setInt(17, a.getSuerte());
			stat.setInt(18, a.getConocimiento());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado el personaje");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void modificar(Personaje a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(update);
			stat.setString(1, a.getUsuario());
			stat.setString(2, a.getNombre());
			stat.setString(3, a.getCampania());
			stat.setString(4, a.getProfesion());
			stat.setInt(5, a.getEdad());
			stat.setString(6, a.getLugarNacimiento());
			stat.setInt(7, a.getFuerza());
			stat.setInt(8, a.getConstitucion());
			stat.setInt(9, a.getTamanio());
			stat.setInt(10, a.getDestreza());
			stat.setInt(11, a.getApariencia());
			stat.setInt(12, a.getCordura());
			stat.setInt(13, a.getInteligencia());
			stat.setInt(14, a.getPoder());
			stat.setInt(15, a.getEducacion());
			stat.setInt(16, a.getIdea());
			stat.setInt(17, a.getSuerte());
			stat.setInt(18, a.getConocimiento());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado el personaje");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
	}

	@Override
	public void eliminar(Personaje a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(delete);
			stat.setString(1, a.getNombre());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya brorrado el usuario");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}
	/*
	 * private Personaje convertir(ResultSet rs) throws SQLException{ String
	 * nombrePersonaje = rs.getString("nombre_personaje"); String profesion =
	 * rs.getString("profesion"); int edad = rs.getInt("edad"); String
	 * lugarNacimiento = rs.getString("lugar_nac"); int fuerza =
	 * rs.getInt("fuerza"); int constitucion = rs.getInt("constitucion"); int
	 * destreza = rs.getInt("destreza"); int apariencia = rs.getInt("apariencia");
	 * int inteligencia = rs.getInt("inteligencia"); int poder = rs.getInt("poder");
	 * int educacion = rs.getInt("educacion"); int idea = rs.getInt("idea"); int
	 * suerte = rs.getInt("suerte"); int conocimiento = rs.getInt("conocimiento");
	 * 
	 * 
	 * Personaje personaje = new Personaje
	 * (nombrePersonaje,profesion,edad,lugarNacimiento,fuerza,constitucion,destreza,
	 * apariencia, inteligencia,poder,educacion,idea, suerte,conocimiento);
	 * personaje.setUsuario(rs.getString("nombre_usuario"));
	 * personaje.setCampania(rs.getString("campaña"));
	 * 
	 * return personaje; }
	 */

	@Override
	public List<Personaje> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Personaje> personajes = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerTodos);
			rs = stat.executeQuery();
			while (rs.next()) {
		//		personajes.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return personajes;
	}
/*
	@Override
	public Personaje obtener(String nombreUsu, String nombrePers, String nombreCamp) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Personaje p = null;
		try {
			stat = con.prepareStatement(obtenerUno);
			stat.setString(1, nombreUsu);
			stat.setString(2, nombrePers);
			stat.setString(3, nombreCamp);
			rs = stat.executeQuery();
			if (rs.next()) {
				//sp = convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return p;
	}*/


	@Override
	public Personaje obtener(Integer id) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

}
