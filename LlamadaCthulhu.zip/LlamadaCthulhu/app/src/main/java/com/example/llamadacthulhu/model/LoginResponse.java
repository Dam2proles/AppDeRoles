package com.example.llamadacthulhu.model;

public class LoginResponse {

    private boolean error;
    private String message;
    private Usuario usuario;

    public LoginResponse(boolean error, String message, Usuario usuario) {
        this.error = error;
        this.message = message;
        this.usuario = usuario;
    }

    public boolean isError() {
        return error;
    }

    public String getMessage() {
        return message;
    }

    public Usuario getUsuario() {
        return usuario;
    }
}
