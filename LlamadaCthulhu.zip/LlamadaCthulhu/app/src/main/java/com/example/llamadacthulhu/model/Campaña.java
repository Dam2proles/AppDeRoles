package com.example.llamadacthulhu.model;

public class Campaña {
    String nombre;
    String creador;
    String descripcion;

    public Campaña(String nombre, String creador, String descripcion) {
        this.nombre = nombre;
        this.creador = creador;
        this.descripcion = descripcion;
    }

    public Campaña() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCreador() {
        return creador;
    }

    public void setCreador(String creador) {
        this.creador = creador;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Campaña{" +
                "nombre='" + nombre + '\'' +
                ", creador='" + creador + '\'' +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}
