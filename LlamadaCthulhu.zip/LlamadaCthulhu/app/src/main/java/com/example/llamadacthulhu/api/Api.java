package com.example.llamadacthulhu.api;

import com.example.llamadacthulhu.model.DefaultResponse;
import com.example.llamadacthulhu.model.LoginResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface Api {

    @FormUrlEncoded
    @POST("crearusuario")
    Call<DefaultResponse>crearUsuario(
            @Field("email") String email,
            @Field("password") String password,
            @Field("nickname") String nick
    );

    @FormUrlEncoded
    @POST("loginusuario")
    Call<LoginResponse> loginUsuario(
            @Field("nick")String nick,
            @Field("password")String password
    );
}
