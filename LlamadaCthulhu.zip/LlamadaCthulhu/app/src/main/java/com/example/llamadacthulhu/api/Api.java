package com.example.llamadacthulhu.api;

import com.example.llamadacthulhu.model.DefaultResponse;
import com.example.llamadacthulhu.model.LoginResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api {

    @FormUrlEncoded
    @POST("crearusuario")
    Call<DefaultResponse>crearUsuario(
            @Field("nickname") String nick,
            @Field("password") String password,
            @Field("email") String email
    );

    @FormUrlEncoded
    @POST("loginusuario")
    Call<LoginResponse> loginUser(
            @Field("nick")String nick,
            @Field("password")String password
    );

    @FormUrlEncoded
    @GET("personajes")
    Call<DefaultResponse>recogerPersonajes(
        @Field("usuario")String nombreuser,
        @Field("nombre")String nombre,
        @Field("aventura")String campaña,
        @Field("lugarNacimiento")String lugNac,
        @Field("profesion")String prof,
        @Field("edad")int edad,
        @Field("fuerza")int fue,
        @Field("constitucion")int con,
        @Field("tamaño")int tam,
        @Field("destrza")int des,
        @Field("apariencia")int apa,
        @Field("cordura")int cor,
        @Field("inteligencia")int inte,
        @Field("poder")int pod,
        @Field("educacion")int edu,
        @Field("idea")int ide,
        @Field("suerte")int sue,
        @Field("conocimiento")int conoc

    );

    @FormUrlEncoded
    @GET("aventuras")
    Call<DefaultResponse>recogercampañas(
        @Field("nombre")String nombrecampaña,
        @Field("creador")String nombrecreador,
        @Field("descripcion")String desc
    );
}
