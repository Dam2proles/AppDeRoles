package com.example.llamadacthulhu.activites;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.llamadacthulhu.model.DefaultResponse;
import com.example.llamadacthulhu.R;
import com.example.llamadacthulhu.api.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class registro extends AppCompatActivity implements View.OnClickListener {
    EditText txtNick;
    EditText txtEmail;
    EditText password;
    EditText conPassword;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        getSupportActionBar().hide();
        txtNick = (EditText) findViewById(R.id.txtNickname);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        password = (EditText) findViewById(R.id.txtCont);
        conPassword = (EditText) findViewById(R.id.txtConfCont);

        findViewById(R.id.btnRegistro).setOnClickListener(this);


    }

    private void registroUsuario(){
        String email = txtEmail.getText().toString().trim();
        String user = txtNick.getText().toString().trim();
        String contr = password.getText().toString().trim();
        String contr2 = conPassword.getText().toString().trim();

        if(email.isEmpty()){
            txtEmail.setError("Tienes que introducir un email.");
            txtEmail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            txtEmail.setError("Introduce un email válido, por favor.");
            txtEmail.requestFocus();
        }
        if(contr.isEmpty()){
            password.setError("Tienes que introducir una contraseña.");
            password.requestFocus();
        }
        if(contr != contr2){
            password.setError("Las contraseñas deben coincidir.");
            password.requestFocus();
        }
        if(contr.length() < 6){
            password.setError("La contraseña tiene que tener mínimo 6 caracteres.");
            password.requestFocus();
        }
        if(user.isEmpty()){
            txtNick.setError("Debes introducir un nombre de usuario.");
            txtNick.requestFocus();
        }

        Call<DefaultResponse> call = RetrofitClient
                .getInstance()
                .getApi()
                .crearUsuario(email,user,contr);

        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                if (response.code() == 201){
                    DefaultResponse dr = response.body();

                    Toast.makeText(registro.this, dr.getMsg(),Toast.LENGTH_LONG).show();
                }else if (response.code() == 422){

                }

            }

            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {

            }
        });


    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnRegistro){
            registroUsuario();
        }
    }
}
