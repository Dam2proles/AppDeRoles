package com.example.llamadacthulhu.activites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.llamadacthulhu.R;
import com.example.llamadacthulhu.api.RetrofitClient;
import com.example.llamadacthulhu.model.LoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class login extends AppCompatActivity implements View.OnClickListener {

    EditText etNick;
    EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        etNick = (EditText)findViewById(R.id.etUser);
        etPassword = (EditText)findViewById(R.id.etContr);

        findViewById(R.id.btnLogin).setOnClickListener(this);

    }

    private void loginUsuario(){
        String user = etNick.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if(user.isEmpty()){
            etNick.setError("Debes introducir un nombre de usuario.");
            etNick.requestFocus();
        }
        if(password.isEmpty()){
            etPassword.setError("Tienes que introducir una contraseña.");
            etPassword.requestFocus();
        }
        Call<LoginResponse> call = RetrofitClient.getInstance().getApi().loginUser(user,password);

        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                LoginResponse loginresponse = response.body();
                if(!loginresponse.isError()){
                    //Cargar Activity de postlogin
                    //guardar prefs usuario
                    Intent intent = new Intent(login.this, postlogin.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(login.this,"Error al loguearse",Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnLogin){
            loginUsuario();
        }
    }
}
