package daoSQL;

import Exceptions.DAOException;
import modelo.Propiedad;
import dao.DAOPropiedad;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SQLPropiedadDAO implements DAOPropiedad {

    final String insert="INSERT INTO PROPIEDAD (nombre_propiedad,id_pers) VALUES(?,?)";
final String update="UPDATE PROPIEDAD SET nombre_propiedad = ? where nombre_propiedad = ? and id_pers = ?" ;
final String delete="DELETE FROM PROPIEDAD WHERE nombre_propiedad = ? AND id_pers = ?";
final String obtenerTodos="SELECT nombre_propiedad,id_pers FROM PROPIEDAD";
final String obtenerLista="SELECT nombre_propiedad,id_pers from PROPIEDAD where id_pers = ?";
    
    
    
    private Connection con;
    

    public SQLPropiedadDAO(Connection con) {
	this.con=con;
}
    
    
    @Override
public void insertar(Propiedad a) throws DAOException {
	PreparedStatement stat= null;
	try {
		stat=con.prepareStatement(insert);
		stat.setString(1,a.getNombrePropiedad());
                    stat.setInt(2,a.getIdPersonaje());
		
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya guardado la propiedad");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	
}
    
    
    @Override
public void modificar(Propiedad a) throws DAOException {
	PreparedStatement stat= null;
	try {
		stat=con.prepareStatement(update);
		stat.setString(1,a.getNombrePropiedad());
                    stat.setInt(3,a.getIdPersonaje());
                    

	stat.executeUpdate();
	if(stat.executeUpdate()==0) {
		throw new DAOException("Puede que no se hayan guardado los cambios de la propiedad");
	}
} catch (SQLException ex) {
	throw new DAOException("Error en sql ",ex);
}
finally {
	if (stat != null) {
		try {
			stat.close();	
		}catch(SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
	}
}
	
}
    
    
    @Override
public void eliminar(Propiedad a) throws DAOException {
	PreparedStatement stat= null;
	try {
		stat=con.prepareStatement(delete);
		stat.setString(1, a.getNombrePropiedad());
                    stat.setInt(2,a.getIdPersonaje());
	stat.executeUpdate();
	if(stat.executeUpdate()==0) {
		throw new DAOException("Puede que no se haya borrado la propiedad");
	}
} catch (SQLException ex) {
	throw new DAOException("Error en sql ",ex);
}
finally {
	if (stat != null) {
		try {
			stat.close();	
		}catch(SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
	}
}
}
    
    
    private Propiedad convertir(ResultSet rs) throws SQLException{
	String nombrePropiedad = rs.getString("nombre_propiedad");
            int idPersonaje =rs.getInt("id_pers");
	
            Propiedad propiedad = new Propiedad (nombrePropiedad,idPersonaje);
	
	return propiedad;
}

@Override
public List<Propiedad> obtenerTodos() throws DAOException {
	PreparedStatement stat = null;
	ResultSet rs = null;
	List <Propiedad> propiedades = new ArrayList<>();
	try {
		stat=con.prepareStatement(obtenerTodos);
		rs=stat.executeQuery();
		while(rs.next()) {
			propiedades.add(convertir(rs));
		}
		}catch(SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
	finally{	
		if (rs != null) {
			try {	
				rs.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
		if (stat != null) {
			try {	
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	return propiedades;
}


@Override
public List<Propiedad> obtenerLista(int id) throws DAOException {
	PreparedStatement stat = null;
	ResultSet rs = null;
	List <Propiedad> propiedades = new ArrayList<>();
	try {
		stat=con.prepareStatement(obtenerLista);
                    stat.setInt(1, id);
		rs=stat.executeQuery();
		while(rs.next()) {
			propiedades.add(convertir(rs));
		}
		}catch(SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
	finally{	
		if (rs != null) {
			try {	
				rs.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
		if (stat != null) {
			try {	
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	return propiedades;
    }

}
