package daoSQL;

import Exceptions.DAOException;
import modelo.Hechizo;
import dao.DAOHechizo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SQLHechizoDAO implements DAOHechizo {

    final String insert="INSERT INTO HECHIZO (nombre_hechizo,id_pers) VALUES(?,?)";
	final String update="UPDATE HECHIZO SET nombre_hechizo = ? where nombre_hechizo = ? and id_pers = ?" ;
	final String delete="DELETE FROM HECHIZO WHERE nombre_hechizo = ? AND id_pers = ?";
	final String obtenerTodos="SELECT nombre_hechizo,id_pers FROM HECHIZO";
	final String obtenerLista="SELECT nombre_hechizo,id_pers from HECHIZO where id_pers = ?";
       
       
       
       private Connection con;
       
   
       public SQLHechizoDAO(Connection con) {
		this.con=con;
	}
       
       
       @Override
	public void insertar(Hechizo a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreHechizo());
                       stat.setInt(2,a.getIdPersonaje());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado el hechizo");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}
       
       
       @Override
	public void modificar(Hechizo a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreHechizo());
                       stat.setInt(3,a.getIdPersonaje());
                       

		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios del hechizo");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}
       
       
       @Override
	public void eliminar(Hechizo a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreHechizo());
                       stat.setInt(2,a.getIdPersonaje());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado el hechizo");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}
       
       
       private Hechizo convertir(ResultSet rs) throws SQLException{
		String nombreHechizo = rs.getString("nombre_hechizo");
               int idPersonaje =rs.getInt("id_pers");
		
               Hechizo hechizo = new Hechizo (nombreHechizo,idPersonaje);
		
		return hechizo;
	}
	
	@Override
	public List<Hechizo> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Hechizo> hechizos = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				hechizos.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return hechizos;
	}


	@Override
	public List<Hechizo> obtenerLista(int id) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Hechizo> hechizos = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerLista);
                       stat.setInt(1, id);
			rs=stat.executeQuery();
			while(rs.next()) {
				hechizos.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return hechizos;
       }

}
