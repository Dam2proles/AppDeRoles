package dao;

import Exceptions.DAOException;
import modelo.Posesion;
import java.util.List;


public interface DAOPosesion  extends DAO<Posesion>{
    
    

    List<Posesion> obtenerLista(int id) throws DAOException;
}
