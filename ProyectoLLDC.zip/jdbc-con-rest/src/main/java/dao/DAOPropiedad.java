package dao;

import Exceptions.DAOException;
import modelo.Propiedad;
import java.util.List;


public interface DAOPropiedad extends DAO<Propiedad>{
    

    List<Propiedad> obtenerLista(int id) throws DAOException;
    
}
