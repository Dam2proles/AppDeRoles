package dao;

import Exceptions.DAOException;
import modelo.LibroMitos;
import java.util.List;


public interface DAOLibroMitos extends DAO<LibroMitos>{
    

    List<LibroMitos> obtenerLista(int id) throws DAOException;
    
}
