package dao;

import Exceptions.DAOException;
import modelo.Familia;
import java.util.List;


public interface DAOFamilia extends DAO<Familia> {
    

    List<Familia> obtenerLista(int id) throws DAOException;
    
}
