package dao;

import Exceptions.DAOException;
import modelo.Hechizo;
import java.util.List;


public interface DAOHechizo extends DAO<Hechizo> {
    
  
    List<Hechizo> obtenerLista(int id) throws DAOException;
    
    
}
