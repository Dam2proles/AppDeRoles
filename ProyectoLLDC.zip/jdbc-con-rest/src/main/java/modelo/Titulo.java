package modelo;

public class Titulo {

	String nombreTitulo;
	int idPersonaje;

	public Titulo(String nombreTitulo, int idPersonaje) {
		this.nombreTitulo = nombreTitulo;
		this.idPersonaje = idPersonaje;
	}

	public String getNombreTitulo() {
		return nombreTitulo;
	}

	public void setNombreTitulo(String nombreTitulo) {
		this.nombreTitulo = nombreTitulo;
	}

	public int getIdPersonaje() {
		return idPersonaje;
	}

	public void setIdPersonaje(int idPersonaje) {
		this.idPersonaje = idPersonaje;
	}

	@Override
	public String toString() {
		return "Titulo: " + getNombreTitulo() + ", idPersonaje: " + getIdPersonaje();
	}

}
