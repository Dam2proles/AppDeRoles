package modelo;

public class Arma {
    
	  String nombreArma;

	    public Arma(String nombreArma) {
	        this.nombreArma = nombreArma;
	    }

	    public String getNombreArma() {
	        return nombreArma;
	    }

	    public void setNombreArma(String nombreArma) {
	        this.nombreArma = nombreArma;
	    }

	    @Override
	    public String toString() {
	        return "Arma: " + getNombreArma();
	    }
    
    
}
