package modelo;



public class Personaje {
    
    int idPersonaje;
    String usuario;
    String nombre;
    String campania;
    String lugarNacimiento;
    String profesion;
    int edad;
    int fuerza;
    int constitucion;
    int tamanio;
    int destreza;
    int apariencia;
    int cordura;
    int inteligencia;
    int poder;
    int educacion;
    int idea;
    int suerte;
    int conocimiento;
    

    public Personaje(int idPersonaje,String nombre,String profesion,int edad, String lugarNacimiento,int fuerza, int constitucion, int tamanio,int destreza,
                     int apariencia,int cordura, int inteligencia, int poder, int educacion, int idea, int suerte, int conocimiento) {
        
        this.idPersonaje = idPersonaje;
        this.nombre = nombre;
        this.profesion = profesion;
        this.edad = edad;
        this.lugarNacimiento = lugarNacimiento;
        this.fuerza = fuerza;
        this.constitucion = constitucion;
        this.tamanio = tamanio;
        this.destreza = destreza;
        this.apariencia = apariencia;
        this.cordura = cordura;
        this.inteligencia = inteligencia;
        this.poder = poder;
        this.educacion = educacion;
        this.idea = idea;
        this.suerte = suerte;
        this.conocimiento = conocimiento;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCampania() {
        return campania;
    }

    public void setCampania(String campania) {
        this.campania = campania;
    }
    
    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getLugarNacimiento() {
        return lugarNacimiento;
    }

    public void setLugarNacimiento(String lugarNacimiento) {
        this.lugarNacimiento = lugarNacimiento;
    }

    public int getFuerza() {
        return fuerza;
    }

    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    public int getConstitucion() {
        return constitucion;
    }

    public void setConstitucion(int constitucion) {
        this.constitucion = constitucion;
    }

    public int getTamanio() {
        return tamanio;
    }

    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }

    public int getDestreza() {
        return destreza;
    }

    public void setDestreza(int destreza) {
        this.destreza = destreza;
    }

    public int getApariencia() {
        return apariencia;
    }

    public void setApariencia(int apariencia) {
        this.apariencia = apariencia;
    }

    public int getCordura() {
        return cordura;
    }

    public void setCordura(int cordura) {
        this.cordura = cordura;
    }

    public int getInteligencia() {
        return inteligencia;
    }

    public void setInteligencia(int inteligencia) {
        this.inteligencia = inteligencia;
    }

    public int getPoder() {
        return poder;
    }

    public void setPoder(int poder) {
        this.poder = poder;
    }

    public int getEducacion() {
        return educacion;
    }

    public void setEducacion(int educacion) {
        this.educacion = educacion;
    }

    public int getIdea() {
        return idea;
    }

    public void setIdea(int idea) {
        this.idea = idea;
    }

    public int getSuerte() {
        return suerte;
    }

    public void setSuerte(int suerte) {
        this.suerte = suerte;
    }

    public int getConocimiento() {
        return conocimiento;
    }

    public void setConocimiento(int conocimiento) {
        this.conocimiento = conocimiento;
    }

   
    
    

    @Override
    public String toString() {
        return "Nombre: " + nombre + "/n Lugar de Nacimiento: " + lugarNacimiento + "/n Profesion:" + profesion + "/n Fuerza: " + fuerza + 
               "/n Constitucion:" + constitucion + "/n Tamaño: " + tamanio + "/n Destreza: " + destreza + "/n Apariencia: " + apariencia + 
               "/n Cordura: " + cordura + "/n Inteligencia: " + inteligencia + "/n Poder: " + poder + "/n Educacion: " + educacion + "/n Idea: " + idea + 
               "/n Suerte:" + suerte + "/n Conocimiento: " + conocimiento;
    }


    
    
    
    
    
    
    
}