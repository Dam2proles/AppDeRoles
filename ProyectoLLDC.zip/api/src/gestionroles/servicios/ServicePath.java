package gestionroles.servicios;



import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("/servicios")
public class ServicePath extends Application{
	

}