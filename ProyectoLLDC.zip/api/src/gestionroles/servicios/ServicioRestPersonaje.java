package gestionroles.servicios;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import gestionroles.Exceptions.DAOException;
import gestionroles.dao.DAOPersonaje;
import gestionroles.daoSQL.SQLPersonajeDAO;
import gestionroles.modelo.Personaje;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Path("/personaje")
public class ServicioRestPersonaje {

	@Inject
	private DataSource dataSource;

	
	// todas las personajes
	@GET
	@Path("/damepersonajes")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPersonajes() {

		Response.Status responseStatus = Response.Status.OK;
		List<Personaje> personajeRg = new ArrayList<Personaje>();

		try {
			Connection connection = dataSource.getConnection();
			DAOPersonaje man = new SQLPersonajeDAO(connection);
			personajeRg = man.obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(personajeRg).build();
		else
			return Response.status(responseStatus).build();
	}

	// unico personaje

	@GET
	@Path("/{id_personaje}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getPersonaje(@PathParam("id_personaje") int idPersonaje) {

		Response.Status responseStatus = Response.Status.OK;
		Personaje personaje = null;
		try {
			Connection connection = dataSource.getConnection();
			SQLPersonajeDAO man = new SQLPersonajeDAO(connection);
			personaje = man.obtener(idPersonaje);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(personaje).build();
		else
			return Response.status(responseStatus).build();
	}

	// actualizar personaje
	@PUT
	@Path("/{id_personaje}")
	@Consumes(APPLICATION_JSON)
	public Response putPersonaje(@PathParam("id_personaje") int idCampania, Personaje personaje) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLPersonajeDAO man = new SQLPersonajeDAO(connection);
			man.modificar(personaje);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	// insertar personaje
	@POST
	@Consumes(APPLICATION_JSON)
	public Response postPersonaje(@Context UriInfo uriInfo, Personaje personaje) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			Connection connection = dataSource.getConnection();
			SQLPersonajeDAO man = new SQLPersonajeDAO(connection);
			man.insertar(personaje);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

	/*// borrar personaje
	@DELETE
	@Path("/{id_personaje}")
	public Response deletePersonaje(@PathParam("id_personaje") Personaje personaje) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLPersonajeDAO man = new SQLPersonajeDAO(connection);
			man.eliminar(personaje);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
	*/
}
