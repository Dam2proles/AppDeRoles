package gestionroles.servicios;
import javax.inject.Inject;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import gestionroles.Exceptions.DAOException;
import gestionroles.daoSQL.SQLCampaniaDAO;
import gestionroles.modelo.Campania;

import java.net.URI;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Path("/campania")
public class ServicioRestCampania {

	@Inject
	private DataSource dataSource;

	// todas las campanias
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCampanias() {

		Response.Status responseStatus = Response.Status.OK;
		List<Campania> campaniaRg = new LinkedList<Campania>();

		try {
			Connection connection = dataSource.getConnection();
			SQLCampaniaDAO man = new SQLCampaniaDAO(connection);
			campaniaRg = man.obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(campaniaRg).build();
		else
			return Response.status(responseStatus).build();
	}

	// unica campania
	@GET
	@Path("/{nombre_camp}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCampania(@PathParam("nombre_camp") String idCampania) {

		Response.Status responseStatus = Response.Status.OK;
		Campania campania = null;
		try {
			Connection connection = dataSource.getConnection();
			SQLCampaniaDAO man = new SQLCampaniaDAO(connection);
			;
			campania = man.obtener(idCampania);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(campania).build();
		else
			return Response.status(responseStatus).build();
	}

	// actualizar campania
	@PUT
	@Path("/{nombre_camp}")
	@Consumes(APPLICATION_JSON)
	public Response putCampania(@PathParam("nombre_camp") String idCampania, Campania camapnia) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLCampaniaDAO man = new SQLCampaniaDAO(connection);
			man.modificar(camapnia);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	// insertar campania
	@POST
	@Consumes(APPLICATION_JSON)
	public Response postCampania(@Context UriInfo uriInfo, Campania campania) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			Connection connection = dataSource.getConnection();
			SQLCampaniaDAO man = new SQLCampaniaDAO(connection);
			man.insertar(campania);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

   /*	// borrar campania
	@DELETE
	@Path("/{nombre_camp}")
	public Response deleteCampania(@PathParam("nombre_camp") Campania campania) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLCampaniaDAO man = new SQLCampaniaDAO(connection);
			man.eliminar(campania);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
	*/
}
