
package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.SerEncontrado;


public interface DAOSerEncontrado extends DAO<SerEncontrado>{
    

    List<SerEncontrado> obtenerLista(int id) throws DAOException;
}
