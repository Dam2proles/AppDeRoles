package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Posesion;


public interface DAOPosesion  extends DAO<Posesion>{
    
    

    List<Posesion> obtenerLista(int id) throws DAOException;
}
