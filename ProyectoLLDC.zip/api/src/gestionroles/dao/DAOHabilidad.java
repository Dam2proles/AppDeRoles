package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Habilidad;


public interface DAOHabilidad extends DAO<Habilidad>{
    
    Habilidad obtener (String nombreHabilidad) throws DAOException;
    
}
