package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Herida;


public interface DAOHerida extends DAO<Herida>{
    
    
    List<Herida> obtenerLista(int id) throws DAOException;
}
