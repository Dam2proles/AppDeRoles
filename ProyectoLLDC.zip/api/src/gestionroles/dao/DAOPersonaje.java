package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Personaje;


public interface DAOPersonaje extends DAO<Personaje>{

    Personaje obtener (int id) throws DAOException;
    List<Personaje>obtenerPersonajesUsuario(String usuario) throws DAOException;
    String obtenerProfesion(int idPersonaje) throws DAOException;
    int obtenerEdad(int idPers) throws DAOException;
    
}
