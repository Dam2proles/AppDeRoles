package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Trastorno;


public interface DAOTrastorno extends DAO<Trastorno>{
    
 
    List<Trastorno> obtenerLista(int id) throws DAOException;
}
