package gestionroles.dao;

import java.util.Date;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Usuario;



public interface DAOUsuario extends DAO <Usuario>{
    
       Usuario obtener (String nombre) throws DAOException;
       String obtenerEmail(String nombre) throws DAOException;
       Date obtenerFechaNacimiento(String nombre) throws DAOException;
       String obtenerTipoPerfil(String nombre) throws DAOException;
       byte[] obtenerImagen(String nombre) throws DAOException;	
       Usuario obtenerLogin (String nombre,String contrasenia) throws DAOException;
}
