package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Campania;

public interface DAOCampania extends DAO<Campania>{
    
    Campania obtener (String nombreCampania) throws DAOException;
    List<Campania> obtenerCampaniasUsuario(String usuario) throws DAOException;
    String obtenerCreador(String nombreCampania) throws DAOException;
    String obtenerDescripcion(String nombreCampania) throws DAOException;
    
}
