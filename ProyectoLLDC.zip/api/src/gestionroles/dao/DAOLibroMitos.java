package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.LibroMitos;


public interface DAOLibroMitos extends DAO<LibroMitos>{
    

    List<LibroMitos> obtenerLista(int id) throws DAOException;
    
}
