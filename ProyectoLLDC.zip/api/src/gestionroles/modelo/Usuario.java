package gestionroles.modelo;

import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Usuario {
	
    
	String nombre;
	String contrasenia;
       String email;
       Date fechaNacimiento;
       String sexo;
       String tipoPerfil;
       byte[] imagen;
	
	public Usuario(String nombre,String contrasenia,String email,String sexo,String tipoPerfil) {
		this.nombre=nombre;
		this.contrasenia=contrasenia;
               this.email=email;
               this.sexo = sexo;
               this.tipoPerfil = tipoPerfil;
	}
	
	public Usuario() {
		
	}



	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getContrasenia() {
		return contrasenia;
	}
	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
       
       public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

       public Date getFechaNacimiento() {
           return fechaNacimiento;
       }

       public void setFechaNacimiento(Date fechaNacimiento) {
           this.fechaNacimiento = fechaNacimiento;
       }

       public String getSexo() {
           return sexo;
       }

       public void setSexo(String sexo) {
           this.sexo = sexo;
       }

       public String getTipoPerfil() {
           return tipoPerfil;
       }

       public void setTipoPerfil(String tipoPerfil) {
           this.tipoPerfil = tipoPerfil;
       }

   public byte[] getImagen() {
       return imagen;
   }

   public void setImagen(byte[] imagen) {
       this.imagen = imagen;
   }
       
       
       
	
	@Override
	public String toString() {
		return  "Nombre: " + getNombre() + " Contrase�a: " + getContrasenia() + " Email: " + 
                          getEmail() + " Fecha nacimiento: " +  getFechaNacimiento() + " Sexo: " + getSexo() + " Tipo Perfil: " +getTipoPerfil() + " Imagen: " + getImagen();
	}
}