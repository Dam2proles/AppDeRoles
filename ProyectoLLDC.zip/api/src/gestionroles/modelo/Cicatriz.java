package gestionroles.modelo;

public class Cicatriz {
    
    
    
    String nombreCicatriz ;
    int idPersonaje;

    public Cicatriz(String nombreCicatriz, int idPersonaje) {
        this.nombreCicatriz = nombreCicatriz;
        this.idPersonaje = idPersonaje;
    }


    public String getNombreCicatriz() {
        return nombreCicatriz;
    }

    public void setNombreCicatriz(String nombreCicatriz) {
        this.nombreCicatriz = nombreCicatriz;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }

    @Override
    public String toString() {
        return "Cicatriz: " + getNombreCicatriz() + " idPersonaje: " + getIdPersonaje();
    }
    
    
    
}
