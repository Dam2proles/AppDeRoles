package gestionroles.modelo;


public class Capacidad {
    
    
	  
    String nombreHabilidad;
    String idPersonaje;

    public Capacidad(String nombreHabilidad, String idPersonaje) {
        this.nombreHabilidad = nombreHabilidad;
        this.idPersonaje = idPersonaje;
    }

    public String getNombreHabilidad() {
        return nombreHabilidad;
    }

    public void setNombreHabilidad(String nombreHabilidad) {
        this.nombreHabilidad = nombreHabilidad;
    }

    public String getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(String idPersonaje) {
        this.idPersonaje = idPersonaje;
    }

    @Override
    public String toString() {
        return "Habilidad: " + getNombreHabilidad() + " idPersonaje: " + getIdPersonaje();
    }

    
    
    
}
