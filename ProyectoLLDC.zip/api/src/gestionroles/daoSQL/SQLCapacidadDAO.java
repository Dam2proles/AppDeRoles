package gestionroles.daoSQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.dao.DAOCapacidad;
import gestionroles.modelo.Capacidad;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SQLCapacidadDAO implements DAOCapacidad {

    final String insert="INSERT INTO CAPACIDAD (nombre_habi,id_pers) VALUES(?,?)";
	final String update="UPDATE CAPACIDAD SET nombre_habi = ? where nombre_habi = ? AND id_pers = ?";
	final String delete="DELETE FROM CAPACIDAD WHERE nombre_habi = ? AND id_pers = ?";
	final String obtenerTodos="SELECT nombre_habi,id_pers FROM CAPACIDAD";
	final String obtenerLista="SELECT nombre_habi,id_pers from CAPACIDAD where id_pers = ?";
        
        
        
        private Connection con;
        
    
        public SQLCapacidadDAO(Connection con) {
		this.con=con;
	}
        
        
        @Override
	public void insertar(Capacidad a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreHabilidad());
                        stat.setString(2,a.getIdPersonaje());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}
        
        
        @Override
	public void modificar(Capacidad a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreHabilidad());
                        stat.setString(3, a.getIdPersonaje());

		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}
        
        
        @Override
	public void eliminar(Capacidad a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreHabilidad());
                        stat.setString(2,a.getIdPersonaje());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}
        
        
        private Capacidad convertir(ResultSet rs) throws SQLException{
		String nombreHabilidad = rs.getString("nombre_habi");
                String idPersonaje = rs.getString("id_pers");
		
                Capacidad habilidad = new Capacidad (nombreHabilidad,idPersonaje);
		
		return habilidad;
	}
	
	@Override
	public List<Capacidad> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Capacidad> habilidades = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				habilidades.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return habilidades;
	}


	@Override
	public List<Capacidad> obtenerLista(int id) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Capacidad> habilidades = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerLista);
                        stat.setInt(1, id);
			rs=stat.executeQuery();
			while(rs.next()) {
				habilidades.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return habilidades;
        }
        
}
