package daoMySQL;

import Exceptions.DAOException;
import modelo.Armamento;
import dao.DAOArmamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLArmamentoDAO implements DAOArmamento {

	final String insert = "INSERT INTO ARMAMENTO (nom_arma,id_pers) VALUES(?,?)";
	final String update = "UPDATE ARMAMENTO SET nom_arma = ? where nom_arma = ? AND id_pers = ?";
	final String delete = "DELETE FROM ARMAMENTO WHERE nom_arma = ? AND id_pers = ?";
	final String obtenerTodos = "SELECT nom_arma,id_pers FROM ARMAMENTO";
	final String obtenerUno = "SELECT nom_arma from ARMAMENTO where id_pers = ?";

	private Connection con;

	public MySQLArmamentoDAO(Connection con) {
		this.con = con;
	}

	@Override
	public void insertar(Armamento a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(insert);
			stat.setString(1, a.getNombreArma());
			stat.setString(2, a.getIdPersonaje());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado el armamento");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void modificar(Armamento a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(update);
			stat.setString(1, a.getNombreArma());
			stat.setString(3, a.getIdPersonaje());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se hayan guardado los cambios del armamento");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void eliminar(Armamento a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(delete);
			stat.setString(1, a.getNombreArma());
			stat.setString(2, a.getIdPersonaje());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya borrado el armamento");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
	}

	private Armamento convertir(ResultSet rs) throws SQLException {
		String nombreArma = rs.getString("nom_arma");
		String idPersonaje = rs.getString("id_pers");

		Armamento arma = new Armamento(nombreArma, idPersonaje);

		return arma;
	}

	@Override
	public List<Armamento> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Armamento> armas = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerTodos);
			rs = stat.executeQuery();
			while (rs.next()) {
				armas.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return armas;
	}

	public List<Armamento> obtenerLista() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Armamento> armas = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerUno);
			rs = stat.executeQuery();
			while (rs.next()) {
				armas.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return armas;
	}

}
