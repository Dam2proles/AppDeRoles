package daoMySQL;

import Exceptions.DAOException;
import modelo.Posesion;
import dao.DAOPosesion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLPosesionDAO implements DAOPosesion {

	final String insert = "INSERT INTO POSESION (nombre_posesion,id_pers) VALUES(?,?)";
	final String update = "UPDATE POSESION SET nombre_posesion = ? where nombre_posesion = ? and id_pers = ?";
	final String delete = "DELETE FROM POSESION WHERE nombre_posesion = ? AND id_pers = ?";
	final String obtenerTodos = "SELECT nombre_posesion,id_pers FROM POSESION";
	final String obtenerLista = "SELECT nombre_posesion from POSESION where id_pers = ?";

	private Connection con;

	public MySQLPosesionDAO(Connection con) {
		this.con = con;
	}

	@Override
	public void insertar(Posesion a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(insert);
			stat.setString(1, a.getNombrePosesion());
			stat.setInt(2, a.getIdPersonaje());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void modificar(Posesion a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(update);
			stat.setString(1, a.getNombrePosesion());
			stat.setInt(3, a.getIdPersonaje());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se hayan guardado los cambios");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void eliminar(Posesion a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(delete);
			stat.setString(1, a.getNombrePosesion());
			stat.setInt(2, a.getIdPersonaje());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya borrado");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
	}

	private Posesion convertir(ResultSet rs) throws SQLException {
		String nombrePosesion = rs.getString("nombre_posesion");
		int idPersonaje = rs.getInt("id_pers");

		Posesion posesion = new Posesion(nombrePosesion, idPersonaje);

		return posesion;
	}

	@Override
	public List<Posesion> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Posesion> posesiones = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerTodos);
			rs = stat.executeQuery();
			while (rs.next()) {
				posesiones.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return posesiones;
	}

	@Override
	public List<Posesion> obtenerLista() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Posesion> posesiones = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerLista);
			rs = stat.executeQuery();
			while (rs.next()) {
				posesiones.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return posesiones;
	}
}
