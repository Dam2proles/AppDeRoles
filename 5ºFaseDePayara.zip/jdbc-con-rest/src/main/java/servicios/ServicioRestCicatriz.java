package servicios;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import Exceptions.DAOException;
import daoMySQL.MySQLCicatrizDAO;
import modelo.Cicatriz;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Path("/cicatriz")
public class ServicioRestCicatriz {

	@Inject
	private DataSource dataSource;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCicatriz() {

		Response.Status responseStatus = Response.Status.OK;
		List<Cicatriz> cicatrizRg = new LinkedList<Cicatriz>();

		try {
			Connection connection = dataSource.getConnection();
			MySQLCicatrizDAO man = new MySQLCicatrizDAO(connection);
			cicatrizRg = man.obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(cicatrizRg).build();
		else
			return Response.status(responseStatus).build();
	}


	@PUT
	@Path("/{nombre_cicatriz}")
	@Consumes(APPLICATION_JSON)
	public Response putCicatriz(@PathParam("nombre_cicatriz") int idCampania, Cicatriz cicatriz) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			MySQLCicatrizDAO man = new MySQLCicatrizDAO(connection);
			man.modificar(cicatriz);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	@POST
	@Consumes(APPLICATION_JSON)
	public Response postCicatriz(@Context UriInfo uriInfo, Cicatriz cicatriz) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			Connection connection = dataSource.getConnection();
			MySQLCicatrizDAO man = new MySQLCicatrizDAO(connection);
			man.insertar(cicatriz);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

	@DELETE
	@Path("/{nombre_cicatriz}")
	public Response deleteCicatriz(@PathParam("nombre_cicatriz") Cicatriz cicatriz) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			MySQLCicatrizDAO man = new MySQLCicatrizDAO(connection);
			man.eliminar(cicatriz);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
}