package dao;

import Exceptions.DAOException;
import modelo.Armamento;
import java.util.List;


public interface DAOArmamento extends DAO<Armamento>{
    
    List<Armamento> obtenerLista() throws DAOException;
    
    
}
