
package dao;

import Exceptions.DAOException;
import modelo.SerEncontrado;
import java.util.List;


public interface DAOSerEncontrado extends DAO<SerEncontrado>{
    

    List<SerEncontrado> obtenerLista() throws DAOException;
}
