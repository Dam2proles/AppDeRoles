package dao;

import Exceptions.DAOException;
import modelo.Cicatriz;
import java.util.List;


public interface DAOCicatriz  extends DAO<Cicatriz>{
    
    
    List<Cicatriz> obtenerLista() throws DAOException;
    
}
