package dao;

import Exceptions.DAOException;
import modelo.ObjetoMagico;
import java.util.List;


public interface DAOObjetoMagico extends DAO<ObjetoMagico>{
    
    

    List<ObjetoMagico> obtenerLista() throws DAOException;
}
