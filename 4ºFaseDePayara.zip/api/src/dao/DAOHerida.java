package dao;

import Exceptions.DAOException;
import modelo.Herida;
import java.util.List;


public interface DAOHerida extends DAO<Herida>{
    
    
    List<Herida> obtenerLista() throws DAOException;
}
