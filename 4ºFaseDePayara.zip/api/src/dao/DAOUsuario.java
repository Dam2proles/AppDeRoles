package dao;

import Exceptions.DAOException;
import modelo.Usuario;



public interface DAOUsuario extends DAO <Usuario>{
    
       Usuario obtener (String nombre) throws DAOException;
    
}
