package dao;

import Exceptions.DAOException;
import modelo.Arma;


public interface DAOArma  extends DAO<Arma>{
    
    Arma obtener (String nombreArma) throws DAOException;
    
}
