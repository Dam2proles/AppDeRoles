package dao;

import Exceptions.DAOException;
import modelo.Personaje;


public interface DAOPersonaje extends DAO<Personaje>{

    Personaje obtener (int id) throws DAOException;
    
    
    
}
