package modelo;

public class Campania {
	public String nombre;
	public String descripcion;
	public String creador;
	
	public Campania(String nombre,String descripcion,String creador) {
		this.nombre=nombre;
		this.descripcion=descripcion;
		this.creador=creador;
	}
	
	public Campania() {
		// TODO Auto-generated constructor stub
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCreador() {
		return creador;
	}

	public void setCreador(String creador) {
		this.creador = creador;
	}

	@Override
	public String toString() {
		return "Campania [nombre=" + nombre + ", descripcion=" + descripcion + ", creador=" + creador + "]";
	}


	
	
}
