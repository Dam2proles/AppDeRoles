package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Cicatriz;
import gestionroles.dao.DAOCicatriz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class SQLCicatrizDAO implements DAOCicatriz{
    
    
        final String insert="INSERT INTO CICATRIZ (nombre_cicatriz,id_pers) VALUES(?,?)";
	final String update="UPDATE CICATRIZ SET nombre_cicatriz = ? where nombre_cicatriz = ? and id_pers = ?" ;
	final String delete="DELETE FROM CICATRIZ WHERE nombre_cicatriz = ? AND id_pers = ?";
	final String obtenerTodos="SELECT nombre_cicatriz,id_pers FROM CICATRIZ";
	final String obtenerLista="SELECT nombre_cicatriz,id_pers from CICATRIZ where id_pers = ?";
        
        
        
        private Connection con;
        
    
        public SQLCicatrizDAO(Connection con) {
		this.con=con;
	}
        
        
        @Override
	public void insertar(Cicatriz a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreCicatriz());
                        stat.setInt(2,a.getIdPersonaje());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado la cicatriz");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}
        
        
        @Override
	public void modificar(Cicatriz a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreCicatriz());
                        stat.setString(1,a.getNombreCicatriz());
                        stat.setInt(3,a.getIdPersonaje());
                        

		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios de la cicatriz");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}
        
        
        @Override
	public void eliminar(Cicatriz a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreCicatriz());
                        stat.setInt(2,a.getIdPersonaje());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado la cicatriz");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}
        
        
        private Cicatriz convertir(ResultSet rs) throws SQLException{
		String nombreCicatriz = rs.getString("nombre_cicatriz");
                int idPersonaje =rs.getInt("id_pers");
		
                Cicatriz cicatriz = new Cicatriz (nombreCicatriz,idPersonaje);
		
		return cicatriz;
	}
	
	@Override
	public List<Cicatriz> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Cicatriz> cicatrices = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				cicatrices.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return cicatrices;
	}


	@Override
	public List<Cicatriz> obtenerLista(int id) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Cicatriz> cicatrices = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerLista);
                        stat.setInt(1, id);
			rs=stat.executeQuery();
			while(rs.next()) {
				cicatrices.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return cicatrices;
        }
        
        
        

    
}
