package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Trastorno;
import gestionroles.dao.DAOTrastorno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class SQLTrastornoDAO implements DAOTrastorno{
    
    
    
        final String insert="INSERT INTO TRASTORNO (nombre_trastorno,id_pers) VALUES(?,?)";
	final String update="UPDATE TRASTORNO SET nombre_trastorno = ? where nombre_trastorno = ? and id_pers = ?" ;
	final String delete="DELETE FROM TRASTORNO WHERE nombre_trastorno = ? AND id_pers = ?";
	final String obtenerTodos="SELECT nombre_trastorno,id_pers FROM TRASTORNO";
	final String obtenerLista="SELECT nombre_trastorno,id_pers from TRASTORNO where id_pers = ?";
        
        
        
        private Connection con;
        
    
        public SQLTrastornoDAO(Connection con) {
		this.con=con;
	}
        
        
        @Override
	public void insertar(Trastorno a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreTrastorno());
                        stat.setInt(2,a.getIdPersonaje());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado el trastorno");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}
        
        
        @Override
	public void modificar(Trastorno a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreTrastorno());
                        stat.setInt(3,a.getIdPersonaje());
                        

		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios del trastorno");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}
        
        
        @Override
	public void eliminar(Trastorno a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreTrastorno());
                        stat.setInt(2,a.getIdPersonaje());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado el trastorno");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}
        
        
        private Trastorno convertir(ResultSet rs) throws SQLException{
		String nombreTrastorno = rs.getString("nombre_trastorno");
                int idPersonaje =rs.getInt("id_pers");
		
                Trastorno hechizo = new Trastorno (nombreTrastorno,idPersonaje);
		
		return hechizo;
	}
	
	@Override
	public List<Trastorno> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Trastorno> trastornos = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				trastornos.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return trastornos;
	}


	@Override
	public List<Trastorno> obtenerLista(int id) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Trastorno> trastornos = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerLista);
                        stat.setInt(1, id);
			rs=stat.executeQuery();
			while(rs.next()) {
				trastornos.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return trastornos;
        }
    
}
