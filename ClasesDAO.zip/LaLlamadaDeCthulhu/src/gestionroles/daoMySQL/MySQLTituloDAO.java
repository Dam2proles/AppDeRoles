package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Titulo;
import gestionroles.dao.DAOTitulo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class MySQLTituloDAO implements DAOTitulo{
    
    
    
        final String insert="INSERT INTO TITULO (nombre_titulo,id_pers) VALUES(?,?)";
	final String update="UPDATE TITULO SET nombre_titulo = ? where nombre_titulo = ? and id_pers = ?" ;
	final String delete="DELETE FROM TITULO WHERE nombre_titulo = ? AND id_pers = ?";
	final String obtenerTodos="SELECT nombre_titulo,id_pers FROM TITULO";
	final String obtenerLista="SELECT nombre_titulo from TITULO where id_pers = ?";
        
        
        
        private Connection con;
        
    
        public MySQLTituloDAO(Connection con) {
		this.con=con;
	}
        
        
        @Override
	public void insertar(Titulo a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreTitulo());
                        stat.setInt(2,a.getIdPersonaje());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado el titulo");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}
        
        
        @Override
	public void modificar(Titulo a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreTitulo());
                        stat.setInt(3,a.getIdPersonaje());
                        

		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios del titulo");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}
        
        
        @Override
	public void eliminar(Titulo a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreTitulo());
                        stat.setInt(2,a.getIdPersonaje());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado el hechizo");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}
        
        
        private Titulo convertir(ResultSet rs) throws SQLException{
		String nombreTitulo = rs.getString("nombre_titulo");
                int idPersonaje =rs.getInt("id_pers");
		
                Titulo titulo = new Titulo (nombreTitulo,idPersonaje);
		
		return titulo;
	}
	
	@Override
	public List<Titulo> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Titulo> titulos = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				titulos.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return titulos;
	}


	@Override
	public List<Titulo> obtenerLista() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Titulo> titulos = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerLista);
			rs=stat.executeQuery();
			while(rs.next()) {
				titulos.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return titulos;
        }
}
