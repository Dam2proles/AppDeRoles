package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.dao.DAOUsuario;
import gestionroles.clase.Usuario;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Blob;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import javax.imageio.ImageIO;

public class MySQLUsuarioDAO implements DAOUsuario {

    final String insert = "INSERT INTO USUARIO (nombre_usu,contrasenia,email,sexo,fec_nacimiento,tipo_perfil) VALUES(?, ?, ?, ?, ?, ?)";
    final String update = "UPDATE USUARIO SET  contrasenia = ?, email = ?,tipo_perfil = ? WHERE nombre_usu = ? ";
    final String delete = "DELETE FROM USUARIO WHERE nombre_usu = ?";
    final String obtenerTodos = "SELECT nombre_usu,contrasenia,email,sexo,fec_nacimiento,tipo_perfil FROM USUARIO";
    final String obtenerUno = "SELECT nombre_usu,contrasenia,email,sexo,fec_nacimiento,tipo_perfil FROM USUARIO WHERE nombre_usu = ?";
    final String obtenerEmail = "SELECT email FROM USUARIO WHERE nombre_usu = ?";
    final String obtenerFechaNacimiento = "SELECT fec_nacimiento FROM USUARIO WHERE nombre_usu = ?";
    final String obtenerTipoPerfil = "SELECT tipo_perfil FROM USUARIO WHERE nombre_usu = ?";
    final String obtenerImagen = "SELECT imagen FROM USUARIO WHERE nombre_usu = ?";

    private Connection con;

    public MySQLUsuarioDAO(Connection con) {
        this.con = con;
    }

    @Override
    public void insertar(Usuario a) throws DAOException {
        PreparedStatement stat = null;
        try {
            stat = con.prepareStatement(insert);
            stat.setString(1, a.getNombre());
            stat.setString(2, a.getContrasenia());
            stat.setString(3, a.getEmail());
            stat.setString(4, a.getSexo());
            stat.setDate(5, new Date(a.getFechaNacimiento().getTime()));
            stat.setString(6, a.getTipoPerfil());
            stat.executeUpdate();
            if (stat.executeUpdate() == 0) {
                throw new DAOException("Puede que no se haya guardado el usuario");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }

    }

    @Override
    public void modificar(Usuario a) throws DAOException {
        PreparedStatement stat = null;
        try {
            stat = con.prepareStatement(update);
            stat.setString(1, a.getNombre());
            stat.setString(2, a.getContrasenia());
            stat.setString(3, a.getEmail());
            stat.setString(4, a.getSexo());
            stat.setDate(5, new Date(a.getFechaNacimiento().getTime()));
            stat.setString(6, a.getTipoPerfil());

            stat.executeUpdate();
            if (stat.executeUpdate() == 0) {
                throw new DAOException("Puede que no se hayan guardado los cambios del usuario");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }

    }

    @Override
    public void eliminar(Usuario a) throws DAOException {
        PreparedStatement stat = null;
        try {
            stat = con.prepareStatement(delete);
            stat.setString(1, a.getNombre());
            stat.executeUpdate();
            if (stat.executeUpdate() == 0) {
                throw new DAOException("Puede que no se haya brorrado el usuario");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }

    }
    

    /*este metodo nos sirve para transformar lo que nos de el resulset
	 * en objetos usuarios
     */
    private Usuario convertir(ResultSet rs) throws SQLException {
        String nombre = rs.getString("nombre_usu");
        String contraseña = rs.getString("contrasenia");
        String email = rs.getString("email");
        String sexo = rs.getString("sexo");
        String tipoPerfil = rs.getString("tipo_perfil");

        Usuario usuario = new Usuario(nombre, contraseña, email, sexo, tipoPerfil);
        usuario.setFechaNacimiento(rs.getDate("fec_nacimiento"));

        //Convertir datos binarios en imagen
        Blob blob = rs.getBlob("imagen");
        byte[] data = blob.getBytes(1, (int) blob.length());
        BufferedImage img = null;
        try {
            img = ImageIO.read(new ByteArrayInputStream(data));
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        //
        
        usuario.setImagen(img);

        return usuario;
    }

    @Override
    public List<Usuario> obtenerTodos() throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        List<Usuario> users = new ArrayList<>();
        try {
            stat = con.prepareStatement(obtenerTodos);
            rs = stat.executeQuery();
            while (rs.next()) {
                users.add(convertir(rs));
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return users;
    }

    @Override
    public Usuario obtener(String nombre) throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        Usuario u = null;
        try {
            stat = con.prepareStatement(obtenerUno);
            stat.setString(1, nombre);
            rs = stat.executeQuery();
            if (rs.next()) {
                u = convertir(rs);
            } else {
                throw new DAOException("No se ha encontrado ese registro");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return u;
    }

    @Override
    public String obtenerEmail(String nombre) throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        Usuario u = null;
        try {
            stat = con.prepareStatement(obtenerEmail);
            stat.setString(1, nombre);
            rs = stat.executeQuery();
            if (rs.next()) {
                u = convertir(rs);
            } else {
                throw new DAOException("No se ha encontrado ese registro");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return u.getEmail();
    }

    @Override
    public Date obtenerFechaNacimiento(String nombre) throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        Usuario u = null;
        try {
            stat = con.prepareStatement(obtenerFechaNacimiento);
            stat.setString(1, nombre);
            rs = stat.executeQuery();
            if (rs.next()) {
                u = convertir(rs);
            } else {
                throw new DAOException("No se ha encontrado ese registro");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return (Date) u.getFechaNacimiento();
    }

    @Override
    public String obtenerTipoPerfil(String nombre) throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        Usuario u = null;
        try {
            stat = con.prepareStatement(obtenerTipoPerfil);
            stat.setString(1, nombre);
            rs = stat.executeQuery();
            if (rs.next()) {
                u = convertir(rs);
            } else {
                throw new DAOException("No se ha encontrado ese registro");
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return u.getTipoPerfil();
    }

    @Override
    public Image obtenerImagen(String nombre) throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        Usuario u = null;
        try {
            stat = con.prepareStatement(obtenerImagen);
            stat.setString(1, nombre);
            rs = stat.executeQuery();

            if (rs.next()) {
                u = convertir(rs);
            } else {
                throw new DAOException("No se ha encontrado ese registro");
            }

        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return u.getImagen();
    }
}
