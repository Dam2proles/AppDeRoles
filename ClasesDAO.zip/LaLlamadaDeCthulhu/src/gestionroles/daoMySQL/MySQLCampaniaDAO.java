package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Campania;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import gestionroles.dao.DAOCampania;


public class MySQLCampaniaDAO implements DAOCampania{
    
        final String insert="INSERT INTO CAMPANIA (nombre_camp,creador,descripcion) VALUES(?, ?, ?)";
	final String update="UPDATE CAMPANIA SET creador = ?, descripcion = ? where nombre_camp = ? ";
	final String delete="DELETE FROM CAMPANIA where nombre_camp = ?";
	final String obtenerTodos="SELECT nombre_camp, descripcion, creador from CAMPANIA";
	final String obtenerUno="SELECT nombre_camp, descripcion, creador from CAMPANIA where nombre_camp = ?";
	
	private Connection con;
	
	public MySQLCampaniaDAO(Connection con) {
		this.con=con;
	}

	@Override
	public void insertar(Campania a) throws DAOException {
		PreparedStatement stat= null;
		try  {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreCampania());
                        stat.setString(2,a.getCreador());
			stat.setString(3,a.getDescripcion());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado la campaña");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}

	@Override
	public void modificar(Campania a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreCampania());
                        stat.setString(2,a.getCreador());
			stat.setString(3,a.getDescripcion());
			
			
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios de la campaña");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}

	@Override
	public void eliminar(Campania a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreCampania());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado la campaña");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}

	
	private Campania convertir(ResultSet rs) throws SQLException{
		String nombre = rs.getString("nombre");
                String creador= rs.getString("creador");
		String descripcion = rs.getString("descripcion");
		
		Campania campania = new Campania (nombre,creador,descripcion);
		
		return campania;
	}
	
	@Override
	public List<Campania> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Campania> campanias = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				campanias.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return campanias;
	}


	@Override
	public Campania obtener(String nombre) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Campania camp = null;
		try {
			stat=con.prepareStatement(obtenerUno);
			stat.setString(1, nombre);
			rs=stat.executeQuery();
			if(rs.next()) {
				camp=convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return camp;
}

    
}
