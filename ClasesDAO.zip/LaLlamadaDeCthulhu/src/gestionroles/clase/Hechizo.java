package gestionroles.clase;


public class Hechizo {
    
    String nombreHechizo;
    int idPersonaje;

    public Hechizo(String nombreHechizo, int idPersonaje) {
        this.nombreHechizo = nombreHechizo;
        this.idPersonaje = idPersonaje;
    }
    
    
    

    public String getNombreHechizo() {
        return nombreHechizo;
    }

    public void setNombreHechizo(String nombreHechizo) {
        this.nombreHechizo = nombreHechizo;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }
    
    
    
}
