package gestionroles.clase;

import java.awt.Image;
import java.util.Date;


public class Usuario {
    
        
	String nombre;
	String contrasenia;
        String email;
        Date fechaNacimiento;
        String sexo;
        String tipoPerfil;
        Image imagen;
	
	public Usuario(String nombre,String contrasenia,String email,String sexo,String tipoPerfil) {
		this.nombre=nombre;
		this.contrasenia=contrasenia;
                this.email=email;
                this.sexo = sexo;
                this.tipoPerfil = tipoPerfil;
	}
	
	public Usuario() {
		
	}



	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getContrasenia() {
		return contrasenia;
	}
	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
        
        public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

        public Date getFechaNacimiento() {
            return fechaNacimiento;
        }

        public void setFechaNacimiento(Date fechaNacimiento) {
            this.fechaNacimiento = fechaNacimiento;
        }

        public String getSexo() {
            return sexo;
        }

        public void setSexo(String sexo) {
            this.sexo = sexo;
        }

        public String getTipoPerfil() {
            return tipoPerfil;
        }

        public void setTipoPerfil(String tipoPerfil) {
            this.tipoPerfil = tipoPerfil;
        }

    public Image getImagen() {
        return imagen;
    }

    public void setImagen(Image imagen) {
        this.imagen = imagen;
    }
        
        
        
	
	@Override
	public String toString() {
		return  "/nNombre" + getNombre() + "/nContraseña: " + getContrasenia() + "/nEmail: " + 
                           getEmail() + "/nFecha nacimiento: " +  getFechaNacimiento() + "/n Sexo: " + getSexo() + "/n Tipo Perfil: " +getTipoPerfil();
	}
}
