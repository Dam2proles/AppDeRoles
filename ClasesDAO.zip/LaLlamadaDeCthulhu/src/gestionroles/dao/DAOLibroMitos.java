package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.LibroMitos;
import java.util.List;


public interface DAOLibroMitos extends DAO<LibroMitos>{
    

    List<LibroMitos> obtenerLista(int id) throws DAOException;
    
}
