package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Armamento;
import java.util.List;


public interface DAOArmamento extends DAO<Armamento>{
    
    List<Armamento> obtenerLista(int id) throws DAOException;
    
    
}
