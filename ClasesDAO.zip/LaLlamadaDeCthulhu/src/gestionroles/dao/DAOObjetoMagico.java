package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.ObjetoMagico;
import java.util.List;


public interface DAOObjetoMagico extends DAO<ObjetoMagico>{
    
    

    List<ObjetoMagico> obtenerLista(int id) throws DAOException;
}
