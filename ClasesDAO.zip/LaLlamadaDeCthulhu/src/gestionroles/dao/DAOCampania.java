package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Campania;

public interface DAOCampania extends DAO<Campania>{
    
    Campania obtener (String nombreCampania) throws DAOException;
    
    
}
