package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Cicatriz;
import java.util.List;


public interface DAOCicatriz  extends DAO<Cicatriz>{
    
    
    List<Cicatriz> obtenerLista() throws DAOException;
    
}
