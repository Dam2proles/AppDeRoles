
package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.SerEncontrado;
import java.util.List;


public interface DAOSerEncontrado extends DAO<SerEncontrado>{
    

    List<SerEncontrado> obtenerLista(int id) throws DAOException;
}
