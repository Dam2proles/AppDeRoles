package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Capacidad;
import java.util.List;


public interface DAOCapacidad extends DAO<Capacidad>{
    
    List<Capacidad> obtenerLista(int id) throws DAOException;
    
}
