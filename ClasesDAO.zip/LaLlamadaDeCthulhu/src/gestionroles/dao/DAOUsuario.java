package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Usuario;
import java.awt.Image;
import java.util.Date;




public interface DAOUsuario extends DAO <Usuario>{
    
       Usuario obtener (String nombre) throws DAOException;
       String obtenerEmail(String nombre) throws DAOException;
       Date obtenerFechaNacimiento(String nombre) throws DAOException;
       String obtenerTipoPerfil(String nombre) throws DAOException;
       Image obtenerImagen(String nombre) throws DAOException;
       
    
}
