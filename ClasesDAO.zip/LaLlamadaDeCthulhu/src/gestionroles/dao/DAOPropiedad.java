package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Propiedad;
import java.util.List;


public interface DAOPropiedad extends DAO<Propiedad>{
    

    List<Propiedad> obtenerLista(int id) throws DAOException;
    
}
