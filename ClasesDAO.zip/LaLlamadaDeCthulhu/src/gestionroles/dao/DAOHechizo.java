package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Hechizo;
import java.util.List;


public interface DAOHechizo extends DAO<Hechizo> {
    
  
    List<Hechizo> obtenerLista() throws DAOException;
    
    
}
