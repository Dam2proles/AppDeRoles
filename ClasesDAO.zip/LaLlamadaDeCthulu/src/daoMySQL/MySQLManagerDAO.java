package daoMySQL;

import dao.DAOCampaña;
import dao.DAOManager;
import dao.DAOPersonaje;
import dao.DAOUsuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLManagerDAO implements DAOManager{
    
    private Connection conn;
	
	private DAOUsuario users =  null;
	private DAOPersonaje personajes = null;
	private DAOCampaña campañas = null;
	
	public MySQLManagerDAO (String host, String username,String password, String database) throws SQLException{
		conn=DriverManager.getConnection("jdbc:mysql://"+host+"/"+database, username, password);
	}
	
	@Override
	public DAOUsuario getDAOUsuario() {
		if(users==null) {
			users=new MySQLUsuarioDAO(conn);
		}
		return users;
	}

	@Override
	public DAOPersonaje getDAOPersonaje() {
		if(personajes==null) {
	//		personajes=new PersonajeMySQLDAO(conn);
		}
		return personajes;
	}

	@Override
	public DAOCampaña getDAOCampaña() {
		if(campañas==null) {
			campañas=new MySQLCampañaDAO(conn);
		}
		return campañas;
	}
    
}
