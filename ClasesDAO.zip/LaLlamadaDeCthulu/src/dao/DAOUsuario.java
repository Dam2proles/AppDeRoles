package dao;

import Exceptions.DAOException;
import gestionroles.Usuario;



public interface DAOUsuario extends DAO <Usuario, String>{
    
       Usuario obtener (String nombre) throws DAOException;
    
}
