package dao;

import Exceptions.DAOException;
import gestionroles.Personaje;


public interface DAOPersonaje extends DAO<Personaje,String>{

    Personaje obtener (String nombreU,String nombreC,String nombreP) throws DAOException;
}
