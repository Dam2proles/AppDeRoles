package dao;

public interface DAOManager {
    
        DAOUsuario getDAOUsuario();
	
	DAOPersonaje getDAOPersonaje();
	
	DAOCampaña getDAOCampaña();
}
