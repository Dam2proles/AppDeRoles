package dao;

import Exceptions.DAOException;
import gestionroles.Campaña;

public interface DAOCampaña extends DAO<Campaña,String>{
    
    Campaña obtener (String nombre) throws DAOException;
    
    
}
