package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Posesion;
import java.util.List;


public interface DAOPosesion  extends DAO<Posesion>{
    
    

    List<Posesion> obtenerLista() throws DAOException;
}
