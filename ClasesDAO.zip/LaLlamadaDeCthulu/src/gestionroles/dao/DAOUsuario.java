package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Usuario;




public interface DAOUsuario extends DAO <Usuario>{
    
       Usuario obtener (String nombre) throws DAOException;
       Usuario obtenerEmail(String nombre) throws DAOException;
       Usuario obtenerFechaNacimiento(String nombre) throws DAOException;
       Usuario obtenerTipoPerfil(String nombre) throws DAOException;
       
    
}
