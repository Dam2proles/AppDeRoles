package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Trastorno;
import java.util.List;


public interface DAOTrastorno extends DAO<Trastorno,String>{
    
 
    List<Trastorno> obtenerLista() throws DAOException;
}
