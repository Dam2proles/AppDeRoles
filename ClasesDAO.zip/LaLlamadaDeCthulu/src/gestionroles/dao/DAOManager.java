package gestionroles.dao;

public interface DAOManager {
    
        DAOUsuario getDAOUsuario();
	
	DAOPersonaje getDAOPersonaje();
	
	DAOCampania getDAOCampaña();
        
        DAOArma getDAOArma();
        
        DAOCicatriz getDAOCicatriz();
        
        DAOFamilia getDAOFamilia();
        
        DAOHabilidad getDAOHabilidad();
        
        DAOHechizo getDAOHechizo();
        
        DAOHerida getDAOHerida();
        
        DAOLibroMitos getDAOLibroMitos();
        
        DAOObjetoMagico getDAOObjetoMagico();
        
        DAOPosesion getDAOPosesion();
        
        DAOPropiedad getDAOPropiedad();
        
        DAOSerEncontrado getDAOSerEncontrado();
        
        DAOTitulo getDAOTitulo();
        
        DAOTrastorno getDAOTrastorno();
}
