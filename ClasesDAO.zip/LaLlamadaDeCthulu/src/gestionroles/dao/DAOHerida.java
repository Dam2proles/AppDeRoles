package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Herida;
import java.util.List;


public interface DAOHerida extends DAO<Herida>{
    
    
    List<Herida> obtenerLista() throws DAOException;
}
