package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Campaña;

public interface DAOCampaña extends DAO<Campaña,String>{
    
    Campaña obtener (String nombreCampaña) throws DAOException;
    
    
}
