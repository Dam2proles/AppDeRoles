package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Titulo;
import java.util.List;


public interface DAOTitulo extends DAO<Titulo,String>{
    

    List<Titulo> obtenerLista() throws DAOException;
}
