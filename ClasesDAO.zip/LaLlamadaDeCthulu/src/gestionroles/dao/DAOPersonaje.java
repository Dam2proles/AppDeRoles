package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Personaje;


public interface DAOPersonaje extends DAO<Personaje>{

    Personaje obtener (int id) throws DAOException;
    
    
    
}
