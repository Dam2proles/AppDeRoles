package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Familia;
import java.util.List;


public interface DAOFamilia extends DAO<Familia> {
    

    List<Familia> obtenerLista() throws DAOException;
    
}
