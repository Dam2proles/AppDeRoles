package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import java.util.List;


public interface DAO<T> {
    
    void insertar(T u) throws DAOException;
    void modificar(T u) throws DAOException;
    void eliminar(T u) throws DAOException;
    List<T>obtenerTodos() throws DAOException;  
    
    
    
}
