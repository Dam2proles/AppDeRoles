package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Habilidad;


public interface DAOHabilidad extends DAO<Habilidad,String>{
    
    Habilidad obtener (String nombreHabilidad) throws DAOException;
    
}
