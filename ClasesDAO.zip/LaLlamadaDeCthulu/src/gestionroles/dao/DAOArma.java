package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Arma;


public interface DAOArma  extends DAO<Arma,String>{
    
    Arma obtener (String nombreArma) throws DAOException;
    
}
