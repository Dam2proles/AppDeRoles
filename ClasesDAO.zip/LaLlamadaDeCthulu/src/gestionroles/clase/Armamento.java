package gestionroles.clase;


public class Armamento {
    
    
    String nombreArma;
    String idPersonaje;

    public Armamento(String nombreArma, String idPersonaje) {
        this.nombreArma = nombreArma;
        this.idPersonaje = idPersonaje;
    }

    public String getNombreArma() {
        return nombreArma;
    }

    public void setNombreArma(String nombreArma) {
        this.nombreArma = nombreArma;
    }

    public String getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(String idPersonaje) {
        this.idPersonaje = idPersonaje;
    }
    
    
    
}
