package gestionroles.clase;


public class Campaña {
    
    
	public String nombreCampaña;
        public String creador;
	public String descripcion;
	
	
	public Campaña(String nombreCampaña,String creador,String descripcion) {
		this.nombreCampaña=nombreCampaña;
		this.creador=creador;
                this.descripcion=descripcion;
	}
	
	public Campaña() {
		
	}
	

	public String getNombreCampaña() {
		return nombreCampaña;
	}

	public void setNombreCampaña(String nombreCampaña) {
		this.nombreCampaña = nombreCampaña;
	}
        
        public String getCreador() {
		return creador;
	}

	public void setCreador(String creador) {
		this.creador = creador;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	

	@Override
	public String toString() {
		return "Nombre: " + nombreCampaña + "/n Creador: " + creador + "/n Descripcion:" + descripcion;
	}
}
