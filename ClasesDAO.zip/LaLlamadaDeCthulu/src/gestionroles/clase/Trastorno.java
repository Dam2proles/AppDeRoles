package gestionroles.clase;


public class Trastorno {
    
    
    String nombreTrastorno;
    int idPersonaje;

    public Trastorno(String nombreTrastorno, int idPersonaje) {
        this.nombreTrastorno = nombreTrastorno;
        this.idPersonaje = idPersonaje;
    }

    

    public String getNombreTrastorno() {
        return nombreTrastorno;
    }

    public void setNombreTrastorno(String nombreTrastorno) {
        this.nombreTrastorno = nombreTrastorno;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }
    
    
    
}
