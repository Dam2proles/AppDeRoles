package gestionroles.clase;


public class Posesion {
    
    String nombrePosesion;
    int idPersonaje;

    public Posesion(String nombrePosesion, int idPersonaje) {
        this.nombrePosesion = nombrePosesion;
        this.idPersonaje = idPersonaje;
    }
    
   

    public String getNombrePosesion() {
        return nombrePosesion;
    }

    public void setNombrePosesion(String nombrePosesion) {
        this.nombrePosesion = nombrePosesion;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }

    
    
    
    
}
