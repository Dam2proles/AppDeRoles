package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.clase.Habilidad;
import gestionroles.dao.DAOHabilidad;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class MySQLHabilidadDAO implements DAOHabilidad{
    
    
    final String insert="INSERT INTO HABILIDAD (nombre_habilidad) VALUES(?)";
	final String update="UPDATE HABILIDAD SET nombre_habilidad = ? where nombre_habilidad = ?";
	final String delete="DELETE FROM HABILIDAD WHERE nombre_habilidad = ?";
	final String obtenerTodos="SELECT nombre_habilidad FROM HABILIDAD";
	final String obtenerUno="SELECT nombre_habilidad from HABILIDAD where nombre_habilidad = ?";
        
        
        
        private Connection con;
        
    
        public MySQLHabilidadDAO(Connection con) {
		this.con=con;
	}
        
        
        @Override
	public void insertar(Habilidad a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreHabilidad());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado la habilidad");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}
        
        
        @Override
	public void modificar(Habilidad a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreHabilidad());

		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios de la habilidad");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}
        
        
        @Override
	public void eliminar(Habilidad a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreHabilidad());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado la habilidad");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}
        
        
        private Habilidad convertir(ResultSet rs) throws SQLException{
		String nombreHabilidad = rs.getString("nombre_habilidad");
		
                Habilidad habilidad = new Habilidad (nombreHabilidad);
		
		return habilidad;
	}
	
	@Override
	public List<Habilidad> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Habilidad> habilidades = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				habilidades.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return habilidades;
	}


	@Override
	public Habilidad obtener(String nombreHabilidad) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Habilidad habilidad = null;
		try {
			stat=con.prepareStatement(obtenerUno);
			stat.setString(1, nombreHabilidad);
			rs=stat.executeQuery();
			if(rs.next()) {
				habilidad=convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return habilidad;
        }
}
