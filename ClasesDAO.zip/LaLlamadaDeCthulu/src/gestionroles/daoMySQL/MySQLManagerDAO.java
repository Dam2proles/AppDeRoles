package gestionroles.daoMySQL;

import gestionroles.dao.DAOArma;
import gestionroles.dao.DAOCampaña;
import gestionroles.dao.DAOCicatriz;
import gestionroles.dao.DAOFamilia;
import gestionroles.dao.DAOHabilidad;
import gestionroles.dao.DAOHechizo;
import gestionroles.dao.DAOHerida;
import gestionroles.dao.DAOLibroMitos;
import gestionroles.dao.DAOManager;
import gestionroles.dao.DAOObjetoMagico;
import gestionroles.dao.DAOPersonaje;
import gestionroles.dao.DAOPosesion;
import gestionroles.dao.DAOPropiedad;
import gestionroles.dao.DAOSerEncontrado;
import gestionroles.dao.DAOTitulo;
import gestionroles.dao.DAOTrastorno;
import gestionroles.dao.DAOUsuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLManagerDAO implements DAOManager{
    
        private Connection conn;
	
	private DAOUsuario users =  null;
	private DAOPersonaje personajes = null;
	private DAOCampaña campañas = null;
        private DAOArma armas = null;
        private DAOCicatriz cicatrices = null;
        private DAOFamilia familiares = null;
        private DAOHabilidad habilidades = null;
        private DAOHechizo hechizos = null;
        private DAOHerida heridas = null;
        private DAOLibroMitos libros = null;
        private DAOObjetoMagico objetos = null;
        private DAOPosesion posesiones = null;
        private DAOPropiedad propiedades = null;
        private DAOSerEncontrado seres = null;
        private DAOTitulo titulos = null;
        private DAOTrastorno trastornos = null;
	
	public MySQLManagerDAO (String host, String username,String password, String database) throws SQLException{
		conn=DriverManager.getConnection("jdbc:mysql://"+host+"/"+database, username, password);
	}
	
	@Override
	public DAOUsuario getDAOUsuario() {
		if(users==null) {
			users=new MySQLUsuarioDAO(conn);
		}
		return users;
	}

	@Override
	public DAOPersonaje getDAOPersonaje() {
		if(personajes==null) {
			//personajes=new PersonajeMySQLDAO(conn);
		}
		return personajes;
	}

	@Override
	public DAOCampaña getDAOCampaña() {
		if(campañas==null) {
			campañas=new MySQLCampañaDAO(conn);
		}
		return campañas;
	}
    
        
        @Override
	public DAOArma getDAOArma() {
		if(armas==null) {
			armas=new MySQLArmaDAO(conn);
		}
		return armas;
	}
        
        @Override
	public DAOCicatriz getDAOCicatriz() {
		if(cicatrices==null) {
			cicatrices=new MySQLCicatrizDAO(conn);
		}
		return cicatrices;
	}
        
        
         @Override
	public DAOFamilia getDAOFamilia() {
		if(familiares==null) {
			familiares=new MySQLFamiliaDAO(conn);
		}
		return familiares;
	}
        
        
        @Override
	public DAOHabilidad getDAOHabilidad() {
		if(habilidades==null) {
			habilidades=new MySQLHabilidadDAO(conn);
		}
		return habilidades;
	}
        
        
        @Override
	public DAOHechizo getDAOHechizo() {
		if(hechizos==null) {
			hechizos=new MySQLHechizoDAO(conn);
		}
		return hechizos;
	}
        
        
        @Override
	public DAOHerida getDAOHerida() {
		if(heridas==null) {
			heridas=new MySQLHeridaDAO(conn);
		}
		return heridas;
	}
        
        
        @Override
	public DAOLibroMitos getDAOLibroMitos() {
		if(libros==null) {
			libros=new MySQLLibroMitosDAO(conn);
		}
		return libros;
	}
        
        
        @Override
	public DAOObjetoMagico getDAOObjetoMagico() {
		if(objetos==null) {
			objetos=new MySQLObjetoMagicoDAO(conn);
		}
		return objetos;
	}
        
        
        @Override
	public DAOPosesion getDAOPosesion() {
		if(posesiones==null) {
			posesiones=new MySQLPosesionDAO(conn);
		}
		return posesiones;
	}
        
        @Override
	public DAOPropiedad getDAOPropiedad() {
		if(propiedades==null) {
			propiedades=new MySQLPropiedadDAO(conn);
		}
		return propiedades;
	}
        
        
        @Override
	public DAOSerEncontrado getDAOSerEncontrado() {
		if(seres==null) {
			seres=new MySQLSerEncontradoDAO(conn);
		}
		return seres;
	}
        
        
        @Override
	public DAOTitulo getDAOTitulo() {
		if(titulos==null) {
			titulos=new MySQLTituloDAO(conn);
		}
		return titulos;
	}
        
        @Override
	public DAOTrastorno getDAOTrastorno() {
		if(trastornos==null) {
			trastornos=new MySQLTrastornoDAO(conn);
		}
		return trastornos;
	}
        
        
}
