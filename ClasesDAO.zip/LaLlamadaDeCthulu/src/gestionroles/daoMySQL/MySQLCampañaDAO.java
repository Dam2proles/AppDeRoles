package gestionroles.daoMySQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.dao.DAOCampaña;
import gestionroles.clase.Campaña;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class MySQLCampañaDAO implements DAOCampaña{
    
        final String insert="INSERT INTO CAMPAÑA (nombre_camp,creador,descripcion) VALUES(?, ?, ?)";
	final String update="UPDATE CAMPAÑA SET creador = ?, descripcion = ? where nombre_camp = ? ";
	final String delete="DELETE FROM CAMPAÑA where nombre_camp = ?";
	final String obtenerTodos="SELECT nombre_camp, descripcion, creador from CAMPAÑA";
	final String obtenerUno="SELECT nombre_camp, descripcion, creador from CAMPAÑA where nombre_camp = ?";
	
	private Connection con;
	
	public MySQLCampañaDAO(Connection con) {
		this.con=con;
	}

	@Override
	public void insertar(Campaña a) throws DAOException {
		PreparedStatement stat= null;
		try  {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreCampaña());
                        stat.setString(2,a.getCreador());
			stat.setString(3,a.getDescripcion());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado la campaña");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}

	@Override
	public void modificar(Campaña a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreCampaña());
                        stat.setString(2,a.getCreador());
			stat.setString(3,a.getDescripcion());
			
			
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios de la campaña");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}

	@Override
	public void eliminar(Campaña a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreCampaña());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado la campaña");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}

	
	private Campaña convertir(ResultSet rs) throws SQLException{
		String nombre = rs.getString("nombre");
                String creador= rs.getString("creador");
		String descripcion = rs.getString("descripcion");
		
		Campaña campaña = new Campaña (nombre,creador,descripcion);
		
		return campaña;
	}
	
	@Override
	public List<Campaña> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Campaña> campañas = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				campañas.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return campañas;
	}


	@Override
	public Campaña obtener(String nombre) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Campaña camp = null;
		try {
			stat=con.prepareStatement(obtenerUno);
			stat.setString(1, nombre);
			rs=stat.executeQuery();
			if(rs.next()) {
				camp=convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return camp;
}

    
}
