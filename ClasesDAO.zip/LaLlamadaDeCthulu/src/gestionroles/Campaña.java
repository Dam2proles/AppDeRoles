package gestionroles;


public class Campaña {
    
    
	public String nombre;
        public String creador;
	public String descripcion;
	
	
	public Campaña(String nombre,String creador,String descripcion) {
		this.nombre=nombre;
		this.creador=creador;
                this.descripcion=descripcion;
	}
	
	public Campaña() {
		
	}
	

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
        
        public String getCreador() {
		return creador;
	}

	public void setCreador(String creador) {
		this.creador = creador;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	

	@Override
	public String toString() {
		return "Nombre: " + nombre + "/n Creador: " + creador + "/n Descripcion:" + descripcion;
	}
}
