import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import Exceptions.DAOException;
import daoMySQL.MySQLSerEncontradoDAO;
import modelo.SerEncontrado;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Path("/serencontrado")
public class ServicioRestSerEncontrado {

	@Inject
	private DataSource dataSource;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getSerEncontrado() {

		Response.Status responseStatus = Response.Status.OK;
		List<SerEncontrado> serEncontradoRg = new LinkedList<SerEncontrado>();

		try {
			Connection connection = dataSource.getConnection();
			MySQLSerEncontradoDAO man = new MySQLSerEncontradoDAO(connection);
			serEncontradoRg = man.obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(serEncontradoRg).build();
		else
			return Response.status(responseStatus).build();
	}


	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getSerEncontradoEsp() {

		Response.Status responseStatus = Response.Status.OK;
		List<SerEncontrado> serEncontradoRg = new LinkedList<SerEncontrado>();

		try {
			Connection connection = dataSource.getConnection();
			MySQLSerEncontradoDAO man = new MySQLSerEncontradoDAO(connection);
			serEncontradoRg = man.obtenerLista();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(serEncontradoRg).build();
		else
			return Response.status(responseStatus).build();
	}
	@PUT
	@Path("/{nombre_ser}")
	@Consumes(APPLICATION_JSON)
	public Response putSerEncontrado(@PathParam("nombre_ser") String id, SerEncontrado SerEncontrado) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			MySQLSerEncontradoDAO man = new MySQLSerEncontradoDAO(connection);
			man.modificar(SerEncontrado);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	@POST
	@Consumes(APPLICATION_JSON)
	public Response postSerEncontrado(@Context UriInfo uriInfo, SerEncontrado SerEncontrado) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			Connection connection = dataSource.getConnection();
			MySQLSerEncontradoDAO man = new MySQLSerEncontradoDAO(connection);
			man.insertar(SerEncontrado);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

	@DELETE
	@Path("/{nombre_ser}")
	public Response deleteArma(@PathParam("nombre_ser") SerEncontrado SerEncontrado) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			MySQLSerEncontradoDAO man = new MySQLSerEncontradoDAO(connection);
			man.eliminar(SerEncontrado);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
}
