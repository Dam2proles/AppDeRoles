package dao;

import Exceptions.DAOException;
import modelo.Campania;

public interface DAOCampania extends DAO<Campania>{
    
    Campania obtener (String nombreCampania) throws DAOException;
    
    
}
