package dao;

import Exceptions.DAOException;
import modelo.Capacidad;
import java.util.List;


public interface DAOCapacidad extends DAO<Capacidad>{
    
    List<Capacidad> obtenerLista(int idPersonaje) throws DAOException;
    
}
