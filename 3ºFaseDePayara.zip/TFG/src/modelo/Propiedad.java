package modelo;


public class Propiedad {
    
    String nombrePropiedad;
    int idPersonaje;

    public Propiedad(String nombrePropiedad, int idPersonaje) {
        this.nombrePropiedad = nombrePropiedad;
        this.idPersonaje = idPersonaje;
    }
    
    

    public String getNombrePropiedad() {
        return nombrePropiedad;
    }

    public void setNombrePropiedad(String nombrePropiedad) {
        this.nombrePropiedad = nombrePropiedad;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }
    
    
    
}
