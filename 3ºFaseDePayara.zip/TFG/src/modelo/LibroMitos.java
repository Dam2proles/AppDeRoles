package modelo;


public class LibroMitos {
    
    
    String nombreLibro;
    int idPersonaje;

    public LibroMitos(String nombreLibro, int idPersonaje) {
        this.nombreLibro = nombreLibro;
        this.idPersonaje = idPersonaje;
    }
    
    

    public String getNombreLibro() {
        return nombreLibro;
    }

    public void setNombreLibro(String nombreLibro) {
        this.nombreLibro = nombreLibro;
    }

    public int getIdPersonaje() {
        return idPersonaje;
    }

    public void setIdPersonaje(int idPersonaje) {
        this.idPersonaje = idPersonaje;
    }
    
    
    
}
