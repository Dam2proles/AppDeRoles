package daoMySQL;

import Exceptions.DAOException;
import modelo.Herida;
import dao.DAOHerida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLHeridaDAO implements DAOHerida {

	final String insert = "INSERT INTO HERIDA (nombre_herida,id_pers) VALUES(?,?)";
	final String update = "UPDATE HERIDA SET nombre_herida= ? where nombre_herida = ? and id_pers = ?";
	final String delete = "DELETE FROM HERIDA WHERE nombre_herida = ? AND id_pers = ?";
	final String obtenerTodos = "SELECT nombre_herida,id_pers FROM HERIDA";
	final String obtenerLista = "SELECT nombre_herida from HERIDA where id_pers = ?";

	private Connection con;

	public MySQLHeridaDAO(Connection con) {
		this.con = con;
	}

	@Override
	public void insertar(Herida a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(insert);
			stat.setString(1, a.getNombreHerida());
			stat.setInt(2, a.getIdPersonaje());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya guardado la herida");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void modificar(Herida a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(update);
			stat.setString(1, a.getNombreHerida());
			stat.setInt(3, a.getIdPersonaje());

			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se hayan guardado los cambios de la herida");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}

	}

	@Override
	public void eliminar(Herida a) throws DAOException {
		PreparedStatement stat = null;
		try {
			stat = con.prepareStatement(delete);
			stat.setString(1, a.getNombreHerida());
			stat.setInt(2, a.getIdPersonaje());
			stat.executeUpdate();
			if (stat.executeUpdate() == 0) {
				throw new DAOException("Puede que no se haya borrado el hechizo");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
	}

	private Herida convertir(ResultSet rs) throws SQLException {
		String nombreHerida = rs.getString("nombre_herida");
		int idPersonaje = rs.getInt("id_pers");

		Herida herida = new Herida(nombreHerida, idPersonaje);

		return herida;
	}

	@Override
	public List<Herida> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Herida> heridas = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerTodos);
			rs = stat.executeQuery();
			while (rs.next()) {
				heridas.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return heridas;
	}

	@Override
	public List<Herida> obtenerLista() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List<Herida> heridas = new ArrayList<>();
		try {
			stat = con.prepareStatement(obtenerLista);
			rs = stat.executeQuery();
			while (rs.next()) {
				heridas.add(convertir(rs));
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ", ex);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
			if (stat != null) {
				try {
					stat.close();
				} catch (SQLException ex) {
					throw new DAOException("Error en sql ", ex);
				}
			}
		}
		return heridas;
	}

}
