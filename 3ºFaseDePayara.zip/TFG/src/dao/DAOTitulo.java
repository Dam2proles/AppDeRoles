package dao;

import Exceptions.DAOException;
import modelo.Titulo;
import java.util.List;


public interface DAOTitulo extends DAO<Titulo>{
    

    List<Titulo> obtenerLista() throws DAOException;
}
