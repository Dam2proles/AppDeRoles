package dao;

import Exceptions.DAOException;
import modelo.Trastorno;
import java.util.List;


public interface DAOTrastorno extends DAO<Trastorno>{
    
 
    List<Trastorno> obtenerLista() throws DAOException;
}
